// MoveGrip.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "MoveGrip.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

//-----------------------------------------------
HINSTANCE g_hInst = NULL;      // Current module instance
HWND      g_hwMain = NULL;     // Main window
HWND      g_hwStatBar = NULL;  // Status bar
HANDLE    g_hLcWnd = NULL;     // Design window
HANDLE    g_hLcDrw = NULL;     // LiteCAD drawing
HANDLE    g_hText1 = NULL;
HANDLE    g_hText2 = NULL;
HANDLE    g_hText3 = NULL;
WCHAR*    g_szPrompt1 = L"Entity ID = ";
WCHAR*    g_szPrompt2 = L"Grip Index = ";
WCHAR*    g_szPrompt3 = L"Position = ";
bool      g_bText = false;

void InitLiteCAD ();
void UninitLiteCAD ();
void CreateObjects ();
void Resize (int SizeType, int Wmain, int Hmain, bool bFromEvent);
void MakePicture (HANDLE hDrw);

void __stdcall ProcGripMove (HANDLE hEnt, int iGrip, double* pX, double* pY, double* pAngle, bool bDrag);
void __stdcall ProcMouseDown (HANDLE hLcWnd, int Button, int Flags, int Xwin, int Ywin, double Xdrw, double Ydrw);
void __stdcall ProcMouseMove (HANDLE hWnd, int Button, int Flags, int Xwin, int Ywin, double X, double Y);

//-----------------------------------------------
int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_MOVEGRIP, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

  InitLiteCAD();

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_MOVEGRIP));

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

  UninitLiteCAD();

	return (int) msg.wParam;
}



//-----------------------------------------------
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//-----------------------------------------------
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MOVEGRIP));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_MOVEGRIP);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

//-----------------------------------------------
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//-----------------------------------------------
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
  g_hInst = hInstance; // Store instance handle in our global variable

  g_hwMain = ::CreateWindow( szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
                           CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);
  if (!g_hwMain){
    return FALSE;
  }

  CreateObjects();

  ::ShowWindow( g_hwMain, nCmdShow );
  ::UpdateWindow( g_hwMain );

  return TRUE;
}

//-----------------------------------------------
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//-----------------------------------------------
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  int wmId, wmEvent;

  switch (message){
    case WM_COMMAND:
      wmId    = LOWORD(wParam);
      wmEvent = HIWORD(wParam);
      // Parse the menu selections:
      switch (wmId){
        case IDM_ABOUT:
          DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
          break;
        case IDM_EXIT:
          DestroyWindow(hWnd);
          break;
        default:
          return DefWindowProc(hWnd, message, wParam, lParam);
      }
      break;

    case WM_SIZE:
      Resize( wParam, LOWORD(lParam), HIWORD(lParam), true );
      break;

    case WM_DESTROY:
      PostQuitMessage(0);
      break;

    default:
      return DefWindowProc(hWnd, message, wParam, lParam);
  }
  return 0;
}

// Message handler for about box.
//-----------------------------------------------
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}




//-----------------------------------------------
void InitLiteCAD ()
{
  // init LiteCAD
  lcPropPutStr( 0, LC_PROP_G_REGCODE, L"12345" );
  lcInitialize(); 
/*
  lcPropPutBool( 0, LC_PROP_G_CURSORSYS, false );
  lcPropPutBool( 0, LC_PROP_G_CURSORCROSS, true );
  lcPropPutInt( 0, LC_PROP_G_CURSORSIZE, 10 );
*/
//  lcPropPutBool( 0, LC_PROP_G_CURSORSYS, true );
//  lcPropPutBool( 0, LC_PROP_G_CURSORCROSS, false );

//  lcPropPutBool( 0, LC_PROP_G_AUTOSELECT, false );
//  lcPropPutBool( 0, LC_PROP_G_AUTOSELECT, false );
//  lcPropPutInt( 0, LC_PROP_G_PANSTEP, 1 );
//  lcPropPutBool( 0, LC_PROP_G_PANFILLING, true );
//  lcPropPutBool( 0, LC_PROP_G_PANLOWRES, false );

  // set event procedures
  lcOnEventGripMove( ProcGripMove );
  lcOnEventMouseDown( ProcMouseDown );
  lcOnEventMouseMove( ProcMouseMove );
}

//-----------------------------------------------
void UninitLiteCAD ()
{
  if (g_hLcDrw){
    lcDeleteDrawing( g_hLcDrw );
  }
  lcUninitialize( false ); // do not save config
}

//-----------------------------------------------
void CreateObjects ()
{
  // StatusBar
  g_hwStatBar = ::CreateWindow( STATUSCLASSNAME, L"NULL", WS_CHILD|WS_VISIBLE|SBARS_SIZEGRIP, 
                                0,0,100,20, g_hwMain, (HMENU)101, g_hInst, NULL );
  INT Parts[2];
  Parts[0] = 300;
  Parts[1] = -1;
  ::SendMessage( g_hwStatBar, SB_SETPARTS, (WPARAM)2, (LPARAM)Parts );

  // create LiteCAD design window, actual size will be set in WM_SIZE event (by function Resize())
  g_hLcWnd = lcCreateWindow( g_hwMain, LC_WS_DEFAULT, 8, 8, 400, 400 );

  // create a drawing
  g_hLcDrw = lcCreateDrawing();
  lcDrwNew( g_hLcDrw, L"", g_hLcWnd );

  MakePicture( g_hLcDrw );
}

//-----------------------------------------------
void Resize (int SizeType, int Wmain, int Hmain, bool bFromEvent)
{
  int  x, y, w, h, Hsb;
  RECT rc;

  if (SizeType == SIZE_MINIMIZED){
    return;
  }
  if (Wmain==0 && Hmain==0){
    return;
  }

  // Statusbar position
  ::SendMessage( g_hwStatBar, WM_SIZE, (WPARAM)SIZE_RESTORED, MAKELONG(Wmain,Hmain) ); 
  ::GetWindowRect( g_hwStatBar, &rc ); 
  Hsb = rc.bottom - rc.top + 1;

  // Design window position
  x = 0;
  y = 0;
  w = Wmain;
  h = Hmain - Hsb;
  lcWndResize( g_hLcWnd, x, y, w, h );

  lcWndSetFocus( g_hLcWnd );  
}


//-----------------------------------------------
void MakePicture (HANDLE hDrw)
{
//  double Xmin, Xmax, Ymin, Ymax, dx, dy, H, R, Gap;
  HANDLE hBlock, hView, hPline; //, hEnt;

  hBlock = lcPropGetHandle( hDrw, LC_PROP_DRW_BLOCK_MODEL );
  hView = lcPropGetHandle( hDrw, LC_PROP_DRW_VIEW_MODEL );
  lcPropPutBool( hView, LC_PROP_VIEW_GRID, false );

  lcBlockClear( hBlock, 0 );
  
  lcBlockAddLine( hBlock, 0,0, 100, 110 );
  lcBlockAddLine( hBlock, 0,60, 120, 50 );
  lcBlockAddCircle( hBlock, 50,20, 20, false );
  hPline = lcBlockAddPolyline( hBlock, LC_PLFIT_QUAD, true, false );
  lcPlineAddVer( hPline, 0, 30, 50 );
  lcPlineAddVer( hPline, 0, 80, 100 );
  lcPlineAddVer( hPline, 0, 100, 30 );
  lcPlineAddVer( hPline, 0, 20, 0 );
//  lcPropPutInt( hPline, LC_PROP_PLINE_FIT, LC_PLFIT_QUAD );

  // set active color
  lcPropPutStr( hDrw, LC_PROP_DRW_COLOR, L"255,255,127" );
  // texts
  g_hText1 = lcBlockAddText( hBlock, g_szPrompt1, 0,100 );
  g_hText2 = lcBlockAddText( hBlock, g_szPrompt2, 0,95 );
  g_hText3 = lcBlockAddText( hBlock, g_szPrompt3, 0,90 );

  lcDrwRegenViews( hDrw, 0 );
  lcWndExeCommand( g_hLcWnd, LC_CMD_ZOOM_EXT, 0 );
}

//-----------------------------------------------
void __stdcall ProcGripMove (HANDLE hEnt, int iGrip, double* pX, double* pY, double* pAngle, bool bDrag)
{
  WCHAR szBuf[128];
  UINT  Id;
  if (bDrag == false){
    Id = lcPropGetInt( hEnt, LC_PROP_ENT_ID );
    swprintf( szBuf, L"%s %d", g_szPrompt1, Id );
    lcPropPutStr( g_hText1, LC_PROP_TEXT_STR, szBuf );
    swprintf( szBuf, L"%s %d", g_szPrompt2, iGrip );
    lcPropPutStr( g_hText2, LC_PROP_TEXT_STR, szBuf );
    swprintf( szBuf, L"%s %.2f  %.2f", g_szPrompt3, *pX, *pY );
    lcPropPutStr( g_hText3, LC_PROP_TEXT_STR, szBuf );
    lcDrwRegenViews( g_hLcDrw, g_hText1 );
    lcDrwRegenViews( g_hLcDrw, g_hText2 );
    lcDrwRegenViews( g_hLcDrw, g_hText3 );
    lcWndRedraw( g_hLcWnd );
    g_bText = true;
  }
}

//-----------------------------------------------
void __stdcall ProcMouseDown (HANDLE hLcWnd, int Button, int Flags, int Xwin, int Ywin, double Xdrw, double Ydrw)
{
  if (g_bText){
    g_bText = false;
    lcPropPutStr( g_hText1, LC_PROP_TEXT_STR, g_szPrompt1 );
    lcPropPutStr( g_hText2, LC_PROP_TEXT_STR, g_szPrompt2 );
    lcPropPutStr( g_hText3, LC_PROP_TEXT_STR, g_szPrompt3 );
    lcDrwRegenViews( g_hLcDrw, g_hText1 );
    lcDrwRegenViews( g_hLcDrw, g_hText2 );
    lcDrwRegenViews( g_hLcDrw, g_hText3 );
    lcWndRedraw( g_hLcWnd );
  }
}

//-----------------------------------------------
void __stdcall ProcMouseMove (HANDLE hWnd, int Button, int Flags, int Xwin, int Ywin, double X, double Y)
{
  WCHAR szBuf[64];
  int id = 0;

  if (hWnd == g_hLcWnd){
    swprintf( szBuf, L"X=%.2f  Y=%.2f", X, Y );
    ::SendMessage( g_hwStatBar, SB_SETTEXT, id, (LPARAM)szBuf );
  }
}
