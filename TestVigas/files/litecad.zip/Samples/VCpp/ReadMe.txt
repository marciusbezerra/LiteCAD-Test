
MS Visual Studio 2008 C++ projects

Output files will be created in the Litecad.dll directory
