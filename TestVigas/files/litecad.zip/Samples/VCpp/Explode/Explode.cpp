/************************************************************************/
/* This console application loads a drawing,                            */
/* explodes its objects and saves the drawing in other file             */
/*                                                                      */
/************************************************************************/
#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <math.h>
#include <conio.h>
#include "..\..\..\API\Litecad.h"

BOOL ConvertFile (LPCWSTR szFileSrc, LPCWSTR szFileDest);

//-----------------------------------------------
int _tmain (int argc, _TCHAR* argv[])
{
  HMODULE hInst;
  WCHAR   szAppDir[256], szFname[256], szBuf[256];
  WCHAR   szFileSrc[256], szFileDest[256];
  WCHAR*  p;
  char    szBufA[512];   // ASCII string
  FILE*   df;
  int     i, j, Len;


  // Get directory of the application's executable
  hInst = ::GetModuleHandle( NULL );
  ::GetModuleFileName( hInst, szAppDir, 255 );
  p = wcsrchr( szAppDir, L'\\' );  // last slash
  if (p){
    // delete filename, remain only path
    p[0] = 0;
  }
  // set paths for Litecad
  lcPropPutStr( 0, LC_PROP_G_DIRDATA, szAppDir ); 
  lcPropPutStr( 0, LC_PROP_G_DIRCFG, szAppDir );  
  // initialize Litecad
  lcInitialize();
  // check paths (just for debugging)
  szBuf[0] = 0;
  wcscpy( szBuf, lcPropGetStr( 0, LC_PROP_G_DIRDLL ));
  wprintf( L"Litecad directory: %s\n", szBuf );
  wcscpy( szBuf, lcPropGetStr( 0, LC_PROP_G_DIRPLUG ));
  wprintf( L"Plugins directory: %s\n", szBuf );
  wcscpy( szBuf, lcPropGetStr( 0, LC_PROP_G_DIRFONTS ));
  wprintf( L"Fonts directory: %s\n", szBuf );
  wcscpy( szBuf, lcPropGetStr( 0, LC_PROP_G_DIRCFG ));
  wprintf( L"Config directory: %s\n\n", szBuf );
  // set version of output file
  lcPlugSetOption( L"dwg", L"EXP_FILEVER", L"21", false );  // ACAD r14 

  // Get filename of .INI file
  swprintf( szFname, L"%s\\explode.ini", szAppDir );
  // open file in text mode
  df = _wfopen( szFname, L"rt" ); 
  if (df){
    // read strings from the .ini file
    while (1){
      szBufA[0] = 0;
      if (fgets( szBufA, 310, df ) == NULL){
        break;
      }
      // convert string to Unicode
      szFileSrc[0] = 0;
      ::MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, szBufA, -1, szFileSrc, 256 );
      szFileSrc[255] = 0;
      // delete ending \n
      p = wcschr( szFileSrc, '\n' );
      if (p){
        p[0] = 0;
      }
      // create filename for converted file (insert " (2)" before extention)
      wcscpy( szFileDest, szFileSrc );
      Len = wcslen( szFileSrc );
      j = Len + 4;
      szFileDest[j] = 0;
      for (i=Len-1; i>0; i--){
        j--;
        szFileDest[j] = szFileDest[i];
        if (szFileDest[i] == L'.'){
          szFileDest[j-1] = L')';
          szFileDest[j-2] = L'2';
          szFileDest[j-3] = L'(';
          szFileDest[j-4] = L' ';
          break; // exit from the cycle
        }
      }

      wprintf( L"Convert file '%s'  ", szFileDest );
      // convert file
      if (ConvertFile( szFileSrc, szFileDest ) == TRUE){
        wprintf( L"OK\n" );
      }else{
        wprintf( L"Error\n" );
      }
    }
    // close file
    fclose( df );
  }
  wprintf( L"Press any key\n" );
  _getch();
	return 0;
}



//-----------------------------------------------
BOOL ConvertFile (LPCWSTR szFileSrc, LPCWSTR szFileDest)
{
  HANDLE hDrw, hBlock, hEnt, hVer0, hVer1, hCirc;
  int    EntType, nVers, FitType, Key;
  BOOL   bClosed, bExploded, bRet;
  double Bulge0, Bulge1, x0, y0, x1, y1, xc, yc, R;
  int    SRCOBJ = 12345;

  hDrw = lcCreateDrawing();
  if (lcDrwLoad( hDrw, szFileSrc, 0, 0 ) == TRUE){
    hBlock = lcPropGetHandle( hDrw, LC_PROP_DRW_BLOCK_MODEL );
    // assign SRCOBJ to all original entities
    hEnt = lcBlockGetFirstEnt( hBlock );
    while( hEnt != 0){
      lcPropPutInt( hEnt, LC_PROP_ENT_KEY, SRCOBJ );
      hEnt = lcBlockGetNextEnt( hBlock, hEnt );
    }
    // enumerate entities of "Model" block and explode them
    hEnt = lcBlockGetFirstEnt( hBlock );
    while( hEnt != 0){
      Key = lcPropGetInt( hEnt, LC_PROP_ENT_KEY );
      if (Key == SRCOBJ){
        // process only original entities
        EntType = lcPropGetInt( hEnt, LC_PROP_ENT_TYPE );
        bExploded = false;
        if (EntType == LC_ENT_POLYLINE){
          bClosed = lcPropGetBool( hEnt, LC_PROP_PLINE_CLOSED );
          FitType = lcPropGetInt( hEnt, LC_PROP_PLINE_FIT );
          nVers   = lcPropGetInt( hEnt, LC_PROP_PLINE_NVERS );
          if (bClosed && nVers==2 && FitType==LC_PLFIT_BULGE){
            hVer0  = lcPlineGetFirstVer( hEnt );
            hVer1  = lcPlineGetNextVer( hEnt, hVer0 );
            Bulge0 = lcPropGetFloat( hVer0, LC_PROP_VER_BULGE );
            Bulge1 = lcPropGetFloat( hVer1, LC_PROP_VER_BULGE );
            if ((Bulge0==1.0 && Bulge1==1.0) || (Bulge0==-1.0 && Bulge1==-1.0)){
              // replace this polyline by circle
              // find the circle center point (xc,yc)
              x0 = lcPropGetFloat( hVer0, LC_PROP_VER_X );
              y0 = lcPropGetFloat( hVer0, LC_PROP_VER_Y );
              x1 = lcPropGetFloat( hVer1, LC_PROP_VER_X );
              y1 = lcPropGetFloat( hVer1, LC_PROP_VER_Y );
              xc = (x0 + x1) / 2.0;
              yc = (y0 + y1) / 2.0;
              // find radius
              R = _hypot( x1-x0, y1-y0 ) / 2.0;
              // create circle
              hCirc = lcBlockAddCircle( hBlock, xc, yc, R, false );
              // set circle's base properties (layer, linetypw, color, etc.) same as of the polyline
              lcEntCopyBase( hCirc, hEnt );
              // delete polyline
              lcEntErase( hEnt, true );
              bExploded = true;
            }
          }
        }
        if (bExploded == false){
          if (lcEntExplode( hEnt, false ) == TRUE){
            // delete original entity
            lcEntErase( hEnt, true );
          }
        }
      }
      hEnt = lcBlockGetNextEnt( hBlock, hEnt );
    }
    bRet = lcDrwSave( hDrw, szFileDest, false, 0 );
  }else{
    bRet = FALSE;
  }
  lcDeleteDrawing( hDrw );
  return bRet;
}

