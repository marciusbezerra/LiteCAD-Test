//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CustomCommand.rc
//
#define IDC_MYICON                      2
#define IDD_CUSTOMCOMMAND_DIALOG        102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_CUSTOMCOMMAND               107
#define IDI_SMALL                       108
#define IDC_CUSTOMCOMMAND               109
#define IDR_MAINFRAME                   128
#define ID_CCMD_FLIP                    201
#define ID_CCMD_SKETCH                  202
#define ID_CCMD_LINE2                   203
#define ID_CCMD_WALL                    204
#define ID_FILE_NEW                     32773
#define ID_FILE_SAVE                    32774
#define ID_FILE_OPEN                    32775
#define ID_FILE_SAVEAS                  32776
#define ID_DRAW_LINE                    32777
#define ID_DRAW_RAY                     32778
#define ID_DRAW_POLYLINE                32780
#define ID_DRAW_RECTANGLE               32781
#define ID_ARC_CONTINUE                 32793
#define ID_ARC_3P                       32794
#define ID_ARC_SCE                      32795
#define ID_ARC_SCA                      32796
#define ID_ARC_SCL                      32797
#define ID_ARC_SEA                      32798
#define ID_ARC_SED                      32799
#define ID_ARC_SER                      32800
#define ID_ARC_CSE                      32801
#define ID_ARC_CSA                      32802
#define ID_ARC_CSL                      32803
#define ID_CIRCLE_CR                    32809
#define ID_CIRCLE_CD                    32810
#define ID_CIRCLE_2P                    32811
#define ID_CIRCLE_3P                    32812
#define ID_DRAW_ELLIPSE                 32813
#define ID_DRAW_XLINE                   32814
#define ID_DRAW_POINT                   32815
#define ID_DRAW_TEXT                    32816
#define ID_DRAW_IMAGE                   32818
#define ID_DRAW_BOUNDARY                32821
#define ID_FILE_RECENT                  32822
#define ID_FILE_INSERT                  32823
#define ID_FILE_PRINT                   32824
#define ID_EDIT_UNDO                    32825
#define ID_EDIT_REDO                    32826
#define ID_EDIT_CUT                     32827
#define ID_EDIT_COPY                    32828
#define ID_EDIT_PASTE                   32829
#define ID_VIEW_LIMITS                  32837
#define ID_VIEW_ZOOMPREV                32841
#define ID_VIEW_ZOOMWIN                 32842
#define ID_VIEW_ZOOMEXT                 32843
#define ID_VIEW_ZOOMSEL                 32844
#define ID_FORMAT_LAYERS                32846
#define ID_FORMAT_COLORS                32847
#define ID_FORMAT_LINETYPES             32848
#define ID_FORMAT_LINEWEIGHTS           32849
#define ID_FORMAT_TEXTSTYLES            32850
#define ID_FORMAT_POINTSTYLES           32851
#define ID_FORMAT_BLOCKS                32852
#define ID_FORMAT_CREATEBLOCK           32853
#define ID_FORMAT_LAYOUTS               32854
#define ID_FORMAT_IMAGES                32855
#define ID_FORMAT_ACQUIREIMAGE          32856
#define ID_MODIFY_ERASE                 32857
#define ID_MODIFY_COPY                  32858
#define ID_MODIFY_MOVE                  32859
#define ID_MODIFY_ROTATE                32860
#define ID_MODIFY_SCALE                 32861
#define ID_MODIFY_MIRROR                32862
#define ID_TOOLS_DISTANCE               32863
#define ID_TOOLS_AREA                   32864
#define ID_TOOLS_OPTIONS                32873
#define ID_TOOLS_MAKERASTER             32874
#define ID_TOOLS_PLUGINS                32875
#define ID_TOOLS_DSET                   32876
#define ID_SEL_OPTIONS                  32877
#define ID_SEL_FILTER                   32878
#define ID_SEL_SELALL                   32879
#define ID_SEL_UNSELALL                 32880
#define ID_SEL_CLAYER                   32881
#define ID_TOOLS_AREAIP                 32882
#define ID_3DVIEWS_TOP                  32884
#define ID_3DVIEWS_BOTTOM               32885
#define ID_3DVIEWS_LEFT                 32886
#define ID_3DVIEWS_RIGHT                32887
#define ID_3DVIEWS_FRONT                32888
#define ID_3DVIEWS_BACK                 32889
#define ID_3DVIEWS_SW                   32895
#define ID_3DVIEWS_SE                   32896
#define ID_3DVIEWS_NE                   32897
#define ID_3DVIEWS_NW                   32898
#define ID_3DVIEWS_VPSET                32899
#define ID_DRAW_CREBLOCK                32900
#define ID_DRAW_INSBLOCK                32901
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
