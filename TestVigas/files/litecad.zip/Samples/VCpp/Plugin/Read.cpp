
#include "stdafx.h"

//-----------------------------------------------
bool ReadFile (LPCWSTR szFileName, HANDLE hLcDb, WCHAR* szError)
{
  char   szBuf[256], szEntType[32];
  int    nEnts;
  double x, y;
  bool   bSuccess;
  HANDLE hBlock, hView;
  FILE*  df = _wfopen( szFileName, L"rt" );
  if (df){
    lcDrwNew( hLcDb, NULL, 0 );
    hBlock = lcPropGetHandle( hLcDb, LC_PROP_DRW_BLOCK_MODEL );
    memset( szBuf,0, sizeof(szBuf) );
    if (fgets( szBuf, 255, df )){
      nEnts = atoi( szBuf );
      Fire_NumItems( nEnts );
    }
    while( fgets( szBuf, 255, df ) ){
      bSuccess = false;
      if (sscanf( szBuf, "%s", szEntType ) == 1){
        if (strcmp( szEntType, "POINT" ) == 0){
          if (sscanf( szBuf, "%s %lf %lf", szEntType, &x, &y ) == 3){
            lcBlockAddPoint( hBlock, x, y );
            Fire_Item();
            bSuccess = true;
          }
        }
      }
      if (bSuccess == false){
        wcscpy( szError, L"Horrible error" );
        break;
      }
    }
    if (szError[0] == 0){
      hView = lcPropGetHandle( hLcDb, LC_PROP_DRW_VIEW_MODEL );
      lcViewSetRect( hView, 0,0,0,0 );  // zoom extents
      lcPropPutBool( hView, LC_PROP_VIEW_GRID, false );
      return true;
    }
  }
  return false;
}
