// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#include <windows.h>



// TODO: reference additional headers your program requires here

#include <stdlib.h>
#include <stdio.h>
#include "litecad.h"
#include "resource.h"

//-----------------------------------------------
struct COptions {
  WCHAR m_szFileName[256];
public:
  int  m_Param1;
  int  m_Param2;
  int  m_Param3;
public:
    COptions ();

  void Load (LPCWSTR szFilename);
  void Save ();
};

typedef void (_stdcall* FUNC_PROGRESS) (int Mode, int IntVal);

void Fire_NumItems (int NumItems);
void Fire_Item ();

bool ReadFile  (LPCWSTR szFileName, HANDLE hLcDb, WCHAR* szError);
bool WriteFile (LPCWSTR szFileName, const BYTE* ImgBuffer, int ImgSize, HANDLE hLcDb, WCHAR* szError);

