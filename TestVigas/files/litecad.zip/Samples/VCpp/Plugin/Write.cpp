
#include "stdafx.h"

void WritePoint (FILE* df, HANDLE hPoint);

//-----------------------------------------------
bool WriteFile (LPCWSTR szFileName, const BYTE* ImgBuffer, int ImgSize, HANDLE hLcDb, WCHAR* szError)
{
  BOOL   bDeleted;
  HANDLE hBlock, hEnt;
  int    nEnts, i, EntType;
  FILE*  df = _wfopen( szFileName, L"wt" );

  if (df == 0){
    return false;
  }
  hBlock = lcPropGetHandle( hLcDb, LC_PROP_DRW_BLOCK_MODEL );
  nEnts = lcPropGetInt( hBlock, LC_PROP_BLOCK_NOBJ );
  Fire_NumItems( nEnts );
  fprintf( df, "%d\n", nEnts );
  i = 0;
  hEnt = lcBlockGetFirstEnt( hBlock );
  while( hEnt ){
    bDeleted = lcPropGetBool( hEnt, LC_PROP_ENT_DELETED );
    if (bDeleted == false){
      EntType = lcPropGetInt( hEnt, LC_PROP_ENT_TYPE );
      switch( EntType ){
        case LC_ENT_POINT: WritePoint( df, hEnt ); break;
      }
      i++;
      Fire_Item();
    }
    hEnt = lcBlockGetNextEnt( hBlock, hEnt );
  }
  fclose( df );
  return true;
}

//-----------------------------------------------
void WritePoint (FILE* df, HANDLE hPoint)
{
  double x, y;
  x = lcPropGetFloat( hPoint, LC_PROP_POINT_X );
  y = lcPropGetFloat( hPoint, LC_PROP_POINT_Y );
  fprintf( df, "POINT %.3f %.3f\n", x, y );
}
