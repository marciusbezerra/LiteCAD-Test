// dllmain.cpp : Defines the entry point for the DLL application.
#include "stdafx.h"

// Global variables
//-----------------------------------------------
HMODULE  g_hInst = 0;
//WCHAR*   g_szMsgTitle = L"FOO plugin for LiteCAD";
COptions g_Options;
FUNC_PROGRESS g_pFuncProgress = NULL;

BOOL Dg_Options (int Index, HWND hwParent, BOOL bSave);

// DLL entry point
//-----------------------------------------------
BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved)
{
  g_hInst = hModule;
  switch (ul_reason_for_call){
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
      break;
  }
  return TRUE;
}

//-----------------------------------------------
void Fire_NumItems (int NumItems)
{
  if (g_pFuncProgress){
    (g_pFuncProgress)( LC_FP_NITEMS, NumItems );
  }
}


//-----------------------------------------------
void Fire_Item ()
{
  if (g_pFuncProgress){
    (g_pFuncProgress)( LC_FP_ITEM, 0 );
  }
}



// returns a number of interfaces
//-----------------------------------------------
int _stdcall LcPlug_CountIfaces ()
{
  return 2;  // read FOO, write FOO
}


// interface type
//-----------------------------------------------
int _stdcall LcPlug_GetIType (int index)
{
  switch( index ){
    case 0: return LC_PLUG_IMPDRW;   //  import a drawing DXF
    case 1: return LC_PLUG_EXPDRW;   //  export a drawing DXF
  }
  return 0;
}


// interface name, description and author
//-----------------------------------------------
void _stdcall LcPlug_GetIName (int index, char* szIName, char* szIDesc, char* szAuthor)
{
  char* szAut = "Oleg Kolbaskin (ok@kolbasoft.com)";
  switch( index ){
    case 0:
      strcpy( szIName, "Read FOO drawing" );
      strcpy( szIDesc, "Allows to read a drawing of FOO format" );
      strcpy( szAuthor, szAut );
      break;
    case 1:
      strcpy( szIName, "Write FOO drawing" );
      strcpy( szIDesc, "Allows to write a drawing of FOO format" );
      strcpy( szAuthor, szAut );
      break;
  }
}


// file extention for the specified interface
//-----------------------------------------------
void _stdcall LcPlug_GetFileExt (int index, char* szExt, char* szInfo)
{
  switch( index ){
    case 0:     // load FOO drawing
      strcpy( szExt, "foo" );
      strcpy( szInfo, "Sample drawing format (*.foo)|*.foo|" );
      break;  
    case 1:     // save FOO drawing
      strcpy( szExt, "foo" );
      strcpy( szInfo, "Sample drawing format (*.foo)|*.foo|" );
      break;  
  }
}


//-----------------------------------------------
int _stdcall LcPlug_GetPreview  (LPCWSTR szFileName, HGLOBAL hGlob, int MaxSize)
{
  int nb=0;
  return nb;  // number of bytes written to the buffer (hGlob)
}


//-----------------------------------------------
BOOL _stdcall LcPlug_Import (int index, HANDLE hLcDb, LPCWSTR szFileName, void* pFuncProgress, WCHAR* szError)
{
  if (index == 0){  // Read DXF file
    g_pFuncProgress = (FUNC_PROGRESS)pFuncProgress;
    if (ReadFile( szFileName, hLcDb, szError )){
      return true;
    }
  }
  return false;
}

//-----------------------------------------------
BOOL _stdcall LcPlug_Export (int index, HANDLE hLcDb, LPCWSTR szFileName, const BYTE* ImgBuffer, int ImgSize, void* pFuncProgress, WCHAR* szError)
{
  if (index == 1){  // Write DXF file
    g_pFuncProgress = (FUNC_PROGRESS)pFuncProgress;
    if (WriteFile( szFileName, ImgBuffer, ImgSize, hLcDb, szError )){
      return true;
    }
  }
  return false;
}

//-----------------------------------------------
void _stdcall LcPlug_LoadOptions (LPCWSTR szDir)
{
  WCHAR szFileName[256];
  wcscpy( szFileName, szDir );
  wcscat( szFileName, L"\\foo_lcplug.cfg" );
  g_Options.Load( szFileName );
}

//-----------------------------------------------
void _stdcall LcPlug_DlgOptions (int Index, HWND hwParent, BOOL bSave)
{
  Dg_Options( Index, hwParent, bSave );
}



