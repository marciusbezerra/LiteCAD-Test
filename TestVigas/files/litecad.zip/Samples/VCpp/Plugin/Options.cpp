
#include "stdafx.h"

//-----------------------------------------------
COptions::COptions () 
{
  memset( m_szFileName, 0, sizeof(m_szFileName) );
  m_Param1 = 0;  
  m_Param2 = 0;
  m_Param3 = 0;
}

//-----------------------------------------------
void COptions::Load (LPCWSTR szFilename)
{
  WCHAR  szKeyVal[32];
  WCHAR* szGroup = L"Params";
  int    nc;

  wcscpy( m_szFileName, szFilename );
  nc = ::GetPrivateProfileString( szGroup, L"PARAM1", L"", szKeyVal, 30, m_szFileName );
  if (nc > 0){
    m_Param1 = _wtoi( szKeyVal );
  }
  nc = ::GetPrivateProfileString( szGroup, L"PARAM2", L"", szKeyVal, 30, m_szFileName );
  if (nc > 0){
    m_Param2 = _wtoi( szKeyVal );
  }
  nc = ::GetPrivateProfileString( szGroup, L"PARAM3", L"", szKeyVal, 30, m_szFileName );
  if (nc > 0){
    m_Param3 = _wtoi( szKeyVal );
  }
}

//-----------------------------------------------
void COptions::Save ()
{
  WCHAR  szKeyVal[32];
  WCHAR* szGroup = L"Params";
  _itow( m_Param1, szKeyVal, 10 );
  ::WritePrivateProfileString( szGroup, L"PARAM1", szKeyVal, m_szFileName );
  _itow( m_Param2, szKeyVal, 10 );
  ::WritePrivateProfileString( szGroup, L"PARAM2", szKeyVal, m_szFileName );
  _itow( m_Param3, szKeyVal, 10 );
  ::WritePrivateProfileString( szGroup, L"PARAM3", szKeyVal, m_szFileName );
}


static BOOL CALLBACK ProcOptions (HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
static void Opt_Init (HWND hDlg);
static void Opt_DialogToVars (HWND hDlg);

extern HMODULE  g_hInst;
extern COptions g_Options;

//-----------------------------------------------
BOOL Dg_Options (int Index, HWND hwParent, BOOL bSave)
{
  COptions opt2 = g_Options;
  int ret = ::DialogBox( g_hInst, MAKEINTRESOURCEW(IDD_OPTIONS), hwParent, (DLGPROC)ProcOptions );
  if (ret == IDOK){
    if (bSave){
      g_Options.Save();
    }
    return true;
  }else{
    // restore
    g_Options = opt2;
  }
  return false;
}

//-----------------------------------------------
BOOL CALLBACK ProcOptions (HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  RECT  rect;
  POINT p;

  switch (uMsg) {
    case WM_INITDIALOG:
      ::GetWindowRect( hDlg, &rect );
      p.x = (::GetSystemMetrics(SM_CXSCREEN)-(rect.right-rect.left))>>1;
      p.y = (::GetSystemMetrics(SM_CYSCREEN)-(rect.bottom-rect.top))>>1;
      ::SetWindowPos( hDlg, HWND_TOP, p.x, p.y, 0,0, SWP_NOSIZE );
      Opt_Init( hDlg );
      return TRUE;

    case WM_CLOSE:
      ::EndDialog( hDlg, 0 );
      return TRUE;

    case WM_COMMAND:
      switch (LOWORD(wParam)) {

        case IDOK:
          Opt_DialogToVars( hDlg );
          ::EndDialog( hDlg, IDOK );
          return TRUE;

        case IDCANCEL:
          ::EndDialog( hDlg, 0 );
          return TRUE;
      }
      break;
  }
  return FALSE;
}


//-----------------------------------------------
void Opt_Init (HWND hDlg)
{
  WCHAR szBuf[32];
  _itow( g_Options.m_Param1, szBuf, 10 );
  ::SetDlgItemText( hDlg, ID_EDIT_PARAM1, szBuf );
  _itow( g_Options.m_Param2, szBuf, 10 );
  ::SetDlgItemText( hDlg, ID_EDIT_PARAM2, szBuf );
  _itow( g_Options.m_Param3, szBuf, 10 );
  ::SetDlgItemText( hDlg, ID_EDIT_PARAM3, szBuf );
/*
  VarToDialog( hDlg, ID_EDIT_PARAM1, L"%d", g_Options.m_Param1 );
  VarToDialog( hDlg, ID_EDIT_PARAM2, L"%d", g_Options.m_Param2 );
  VarToDialog( hDlg, ID_EDIT_PARAM3, L"%d", g_Options.m_Param3 );
*/
}


//-----------------------------------------------
void Opt_DialogToVars (HWND hDlg)
{
  WCHAR szBuf[32];
  ::GetDlgItemText( hDlg, ID_EDIT_PARAM1, szBuf, 30 );
  g_Options.m_Param1 = _wtoi( szBuf );
  ::GetDlgItemText( hDlg, ID_EDIT_PARAM2, szBuf, 30 );
  g_Options.m_Param2 = _wtoi( szBuf );
  ::GetDlgItemText( hDlg, ID_EDIT_PARAM3, szBuf, 30 );
  g_Options.m_Param3 = _wtoi( szBuf );

/*
  int  ival;
  DialogToVar( hDlg, ID_EDIT_PARAM1, 5, L"%ld", &ival );
  ival;
  DialogToVar( hDlg, ID_EDIT_PARAM2, 5, L"%ld", &ival );
  g_Options.m_Param2 = ival;
  DialogToVar( hDlg, ID_EDIT_PARAM3, 5, L"%ld", &ival );
  g_Options.m_Param3 = ival;
*/
}


