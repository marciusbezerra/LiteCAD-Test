This project demonstrates creation of LiteCAD import/export plugin.
The project creates the file "foo.lcplug" in the _Final directory.
Copy it into LiteCAD PlugIns directory (by default "Documents\LiteCAD\Data\PlugIns")
This plugin allows LiteCAD read/write files with *.foo extention, 
this is a sample format which stores only LiteCAD points.


