#pragma once

#include "resource.h"

#define GE_PI 3.14159265358979323846    // 180
#define GE_PI2 (GE_PI / 2.0)    // 1,57079632679489661923    90
#define GE_PI4 (GE_PI / 4.0)    // 0,785398163397448309615   45
#define GE_2PI (GE_PI+GE_PI)    // 6,28318530717958647692   360
#define GE_DEG1    GE_PI / 180.
#define GE_DEG45   GE_PI4
#define GE_DEG90   GE_PI2
#define GE_DEG180  GE_PI
#define GE_DEG270  (GE_PI+GE_PI2)
#define GE_DEG360  GE_2PI

#define BIG_RAD     50.0
#define MAX_MYOBJS  10

// class for movable object
class CMyObject {
public:
  int    m_Id;
  double m_X;
  double m_Y;
  double m_Radius;
  bool   m_bTouch;
public:
    CMyObject ();
 
  void Set (int Id, double X, double Y, double R);
  void Move (double dX, double dY);
};

// functions
void       InitLiteCAD    ();
void       UninitLiteCAD  ();
void       CreateObjects  ();
void       Resize         (int SizeType, int Wmain, int Hmain, bool bFromEvent);
void       MakePicture    (HANDLE hDrw, bool bZoom);
bool       AddMyObject    (HANDLE hBlock, int Id, double X, double Y, double Radius);
CMyObject* GetMyObject    (int Id);
CMyObject* GetMyObject    (double x, double y);
CMyObject* GetTouched     (int i);
double     GetDistBetween (double x0, double y0, double r0, double x1, double y1, double r1);
double     GetDistBetween (const CMyObject* pObj1, const CMyObject* pObj2);
void       MoveObject     (CMyObject* pDragObj, double dx, double dy);
double     GetAngle       (double x0, double y0, double x1, double y1);
bool       MyCommand      (int Cmd);
void       Report         ();
void       UpdateReport   ();

// LiteCAD events procedures
void __stdcall ProcMouseDown (HANDLE hWnd, int Button, int Flags, int Xwin, int Ywin, double Xdrw, double Ydrw);
void __stdcall ProcMouseUp   (HANDLE hWnd, int Button, int Flags, int Xwin, int Ywin, double Xdrw, double Ydrw);
void __stdcall ProcMouseMove (HANDLE hWnd, int Button, int Flags, int Xwin, int Ywin, double Xdrw, double Ydrw);

// Global variables (defined in the "MoveObjects.cpp")
#ifndef _GLOBALS
  extern HINSTANCE g_hInst;
  extern HWND      g_hwMain;    
  extern HWND      g_hwReport;
  extern HANDLE    g_hLcWnd;    
  extern HANDLE    g_hLcDrw;    
  extern CMyObject g_MyObj[];
  extern int       g_nMyObjs;
#endif
