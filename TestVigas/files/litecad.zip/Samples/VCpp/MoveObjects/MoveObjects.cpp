#include "stdafx.h"
#define _GLOBALS
#include "MoveObjects.h"

// Global variables
HINSTANCE g_hInst;      // Current module instance
HWND      g_hwMain;     // Main window
HWND      g_hwReport;   // Report window
HANDLE    g_hLcWnd;     // Design window
HANDLE    g_hLcDrw;     // LiteCAD drawing
CMyObject g_MyObj[MAX_MYOBJS];
int       g_nMyObjs = 0;

int  GetInterPoints (double x1, double y1, double R1, double x2, double y2, double R2,
                     double* pOutX1, double* pOutY1, double* pOutX2, double* pOutY2);
bool HasOverlap (int Id, double x, double y, double R, int Id2, int Id3);
bool HasJump (double dx2, double dy2, double dx, double dy);

//-----------------------------------------------
void InitLiteCAD ()
{
  // init LiteCAD
  lcPropPutStr( 0, LC_PROP_G_REGCODE, L"12345" );
  lcInitialize(); 
/*
  lcPropPutBool( 0, LC_PROP_G_CURSORSYS, false );
  lcPropPutBool( 0, LC_PROP_G_CURSORCROSS, true );
  lcPropPutInt( 0, LC_PROP_G_CURSORSIZE, 10 );
*/
  lcPropPutBool( 0, LC_PROP_G_CURSORSYS, true );
  lcPropPutBool( 0, LC_PROP_G_CURSORCROSS, false );

  lcPropPutBool( 0, LC_PROP_G_AUTOSELECT, false );
  lcPropPutBool( 0, LC_PROP_G_AUTOSELECT, false );
  lcPropPutInt( 0, LC_PROP_G_PANSTEP, 1 );
  lcPropPutBool( 0, LC_PROP_G_PANFILLING, true );
  lcPropPutBool( 0, LC_PROP_G_PANLOWRES, false );

  // set event procedures
  lcOnEventMouseDown( ProcMouseDown );
  lcOnEventMouseUp( ProcMouseUp );
  lcOnEventMouseMove( ProcMouseMove );
}

//-----------------------------------------------
void UninitLiteCAD ()
{
  if (g_hLcDrw){
    lcDeleteDrawing( g_hLcDrw );
  }
  lcUninitialize( false ); // do not save config
}

//-----------------------------------------------
void CreateObjects ()
{
  // create LiteCAD design window, actual size will be set in WM_SIZE event (by function Resize())
  g_hLcWnd = lcCreateWindow( g_hwMain, LC_WS_DEFAULT, 8, 8, 400, 400 );
  // create a drawing
  g_hLcDrw = lcCreateDrawing();
  lcDrwNew( g_hLcDrw, L"", g_hLcWnd );
  MakePicture( g_hLcDrw, true );
//  lcWndExeCommand( g_hLcWnd, LC_CMD_ZOOM_EXT, 0 );
}

//-----------------------------------------------
void Resize (int SizeType, int Wmain, int Hmain, bool bFromEvent)
{
  int  x, y, w, h;

  if (SizeType == SIZE_MINIMIZED){
    return;
  }
  if (Wmain==0 && Hmain==0){
    return;
  }

  // Design window position
  x = 0;
  y = 0;
  w = Wmain;
  h = Hmain;
  lcWndResize( g_hLcWnd, x, y, w, h );

  lcWndSetFocus( g_hLcWnd );  
}

//-----------------------------------------------
void MakePicture (HANDLE hDrw, bool bZoom)
{
  double Xmin, Xmax, Ymin, Ymax, dx, dy, H, R, Gap;
  HANDLE hTStyle, hBlock, hView, hEnt;
  WCHAR* szText;
  WCHAR* szTSName = L"Numbers";   // text style name

  hBlock = lcPropGetHandle( hDrw, LC_PROP_DRW_BLOCK_MODEL );
  hView = lcPropGetHandle( hDrw, LC_PROP_DRW_VIEW_MODEL );
  lcPropPutBool( hView, LC_PROP_VIEW_GRID, false );
  hTStyle = lcDrwGetObjectByName( hDrw, LC_OBJ_TEXTSTYLE, szTSName );
  if (hTStyle == 0){
    // add text style
    hTStyle = lcDrwAddTextStyle( hDrw, szTSName, L"Arial" );
  }
  if (hTStyle){
    // make it active
    lcPropPutHandle( hDrw, LC_PROP_DRW_TEXTSTYLE, hTStyle );
  }

  lcBlockClear( hBlock, 0 );
  g_nMyObjs = 0;

  AddMyObject( hBlock, 1,   0,   0, 8 );
  AddMyObject( hBlock, 2, -15,  15, 10 );
  AddMyObject( hBlock, 3,  15,  15, 10 );
  AddMyObject( hBlock, 4, -15, -15, 10 );
  AddMyObject( hBlock, 5,  15, -15, 10 );
  
  // big circle 1
  lcBlockAddCircle( hBlock, 0,0, BIG_RAD, false );
  // arc text 1
  H = BIG_RAD / 13.0;  // text height
  Gap = H / 5.0;  // distance between text and circle
  szText = L"PRESS LEFT BUTTON ON OBJECT AND DRAG IT";
  R = BIG_RAD + Gap;
  hEnt = lcBlockAddArcText( hBlock, szText, 0,0, R, LC_DEG90, true, H, 1.0, LC_ATA_CENTER );
//  lcPropPutInt( hEnt, LC_PROP_ATEXT_ALIGN, LC_ATA_CENTER );
  lcPropPutStr( hEnt, LC_PROP_ENT_COLOR, L"255,255,127" );
  // arc text 2
  hEnt = lcBlockAddArcText( hBlock, szText, 0,0, R, -LC_DEG90, false, H, 1.0, LC_ATA_CENTER );
  lcPropPutStr( hEnt, LC_PROP_ENT_COLOR, L"255,255,127" );
  // big circle 2
  lcBlockAddCircle( hBlock, 0,0, BIG_RAD+H+Gap+Gap, false );
  lcDrwRegenViews( hDrw, 0 );
  if (bZoom){
    // set area that will be displayed in a window
    dx = lcPropGetFloat( hView, LC_PROP_VIEW_DX ) / 8;
    dy = lcPropGetFloat( hView, LC_PROP_VIEW_DY ) / 8;
    Xmin = lcPropGetFloat( hView, LC_PROP_VIEW_XMIN ) - dx;
    Xmax = lcPropGetFloat( hView, LC_PROP_VIEW_XMAX ) + dx;
    Ymin = lcPropGetFloat( hView, LC_PROP_VIEW_YMIN ) - dy;
    Ymax = lcPropGetFloat( hView, LC_PROP_VIEW_YMAX ) + dy;
    lcViewSetRect2( hView, Xmin, Ymin, Xmax, Ymax );
  }
  UpdateReport();
}

//-----------------------------------------------
bool AddMyObject (HANDLE hBlock, int Id, double X, double Y, double R)
{
  WCHAR szText[32];
  HANDLE hEnt;
  if (g_nMyObjs < MAX_MYOBJS){
    // circle 1
    hEnt = lcBlockAddCircle( hBlock, X, Y, R, true );
    lcPropPutBool( hEnt, LC_PROP_CIRCLE_BORDER, true );
    lcPropPutStr( hEnt, LC_PROP_ENT_COLOR, L"blue" );
    lcPropPutStr( hEnt, LC_PROP_ENT_BCOLOR, L"foreground" );
    lcPropPutInt( hEnt, LC_PROP_ENT_KEY, Id );
    // circle 2
    hEnt = lcBlockAddCircle( hBlock, X, Y, R*0.8, true );
    lcPropPutBool( hEnt, LC_PROP_CIRCLE_BORDER, true );
    lcPropPutStr( hEnt, LC_PROP_ENT_COLOR, L"ltgray" );
    lcPropPutStr( hEnt, LC_PROP_ENT_BCOLOR, L"foreground" );
    lcPropPutInt( hEnt, LC_PROP_ENT_KEY, Id );
    // text
    _itow_s( Id, szText, 30, 10 );
    hEnt = lcBlockAddTextWin2( hBlock, szText, X, Y, LC_TA_CENTER, R*0.5, 1.0, 0, 0 );
    lcPropPutStr( hEnt, LC_PROP_ENT_COLOR, L"0,0,0" );
    lcPropPutInt( hEnt, LC_PROP_ENT_KEY, Id );
    // 
    g_MyObj[g_nMyObjs].Set( Id, X, Y, R );
    g_nMyObjs++;
    return true;
  }
  return false;
}

//-----------------------------------------------
CMyObject* GetMyObject (int Id)
{
  int i;
  for (i=0; i<g_nMyObjs; i++){
    if (Id == g_MyObj[i].m_Id){
      return g_MyObj + i;
    }
  }
  return NULL;
}

//-----------------------------------------------
CMyObject* GetMyObject (double x, double y)
{
  int i;
  double dx, dy, dist;

  for (i=0; i<g_nMyObjs; i++){
    dx = x - g_MyObj[i].m_X;
    dy = y - g_MyObj[i].m_Y;
    dist = _hypot( dx, dy );
    if (dist < g_MyObj[i].m_Radius ){
      return g_MyObj + i;
    }
  }
  return NULL;
}

//-----------------------------------------------
CMyObject* GetTouched (int iTouch)
{
  int i,j;
  for (i=j=0; i<g_nMyObjs; i++){
    if (g_MyObj[i].m_bTouch){
      if (iTouch == j){
        return g_MyObj + i;
      }
      j++;
    }
  }
  return NULL;
}


//-----------------------------------------------
double GetDistBetween (double x0, double y0, double r0, double x1, double y1, double r1)
{
  double dx = x1 - x0;
  double dy = y1 - y0;
  double Dist = _hypot( dx, dy );
  Dist = Dist - r0 - r1;
  return Dist;  // negative means overlap
}

//-----------------------------------------------
double GetDistBetween (const CMyObject* pObj1, const CMyObject* pObj2)
{
  double dx = pObj1->m_X - pObj2->m_X;
  double dy = pObj1->m_Y - pObj2->m_Y;
  double Dist = _hypot( dx, dy );
  Dist = Dist - pObj1->m_Radius - pObj2->m_Radius;
  return Dist;  // negative means overlap
}


// This algorithm has to be improved
//-----------------------------------------------
void MoveObject (CMyObject* pDragObj, double dx, double dy)
{
  CMyObject* pObj2 = NULL;
  CMyObject  TmpObj;
  int    i, j;
  double x, y, R, dist, ang, x0, y0, x2, y2, x3, y3, d2, d3;
  double cx[MAX_MYOBJS], cy[MAX_MYOBJS], cr[MAX_MYOBJS];
  int    cid[MAX_MYOBJS];
  int    nc = 0;
  bool   bOK = false;

  j = 0;
  x0 = pDragObj->m_X;
  y0 = pDragObj->m_Y;
  R = pDragObj->m_Radius;
  TmpObj = *pDragObj;
  TmpObj.Move( dx, dy );
m1:
  // check collision with other objects
  for (i=0; i<g_nMyObjs; i++){
    pObj2 = g_MyObj + i;
    if (pObj2 != pDragObj){
      for (j=0; j<nc; j++){
        if (pObj2->m_Id == cid[j]){
          goto m2;
        }
      }
      dist = GetDistBetween( pObj2, &TmpObj );
      if (dist < 0.0){
        cid[nc] = pObj2->m_Id;
        cx[nc] = pObj2->m_X;
        cy[nc] = pObj2->m_Y;
        cr[nc] = pObj2->m_Radius;
        nc++;
        if (nc == 2){
          goto m3;
        }
        ang = GetAngle( pObj2->m_X, pObj2->m_Y, TmpObj.m_X, TmpObj.m_Y );
        dist = pObj2->m_Radius + R;
        x = pObj2->m_X + dist * cos( ang );
        y = pObj2->m_Y + dist * sin( ang );
        dist = _hypot( x, y ) + R;
        if (dist > BIG_RAD){
          // correct position by big circle
          dist = BIG_RAD - R;
          GetInterPoints( 0,0,dist, pObj2->m_X, pObj2->m_Y, pObj2->m_Radius+R, &x2, &y2, &x3, &y3 );
          d2 = _hypot( x-x2, y-y2 );
          d3 = _hypot( x-x3, y-y3 );
          if (d2 < d3){
            pDragObj->m_X = x2;
            pDragObj->m_Y = y2;
          }else{
            pDragObj->m_X = x3;
            pDragObj->m_Y = y3;
          }
          d2 = _hypot( dx, dy );
          d3 = _hypot( pDragObj->m_X-x0, pDragObj->m_Y-y0 );
          if (d3 > d2){
            pDragObj->m_X = x0;
            pDragObj->m_Y = y0;
          }
          return;
        }else{
          TmpObj.m_X = x;
          TmpObj.m_Y = y;
          goto m1;
        }
      }
m2:   ;
    }
  }
m3:
  if (nc == 2){
    x = TmpObj.m_X;
    y = TmpObj.m_Y;
    GetInterPoints( cx[0], cy[0], cr[0]+R, cx[1], cy[1], cr[1]+R, &x2, &y2, &x3, &y3 );
    d2 = _hypot( x-x2, y-y2 );
    d3 = _hypot( x-x3, y-y3 );
    if (d2 < d3){
      if (HasOverlap( pDragObj->m_Id, x2, y2, R, cid[0], cid[1] ) == false){
        pDragObj->m_X = x2;
        pDragObj->m_Y = y2;
      }
    }else{
      if (HasOverlap( pDragObj->m_Id, x3, y3, R, cid[0], cid[1] ) == false){
        pDragObj->m_X = x3;
        pDragObj->m_Y = y3;
      }
    }
  }else{
    pDragObj->m_X = TmpObj.m_X;
    pDragObj->m_Y = TmpObj.m_Y;
  }
}

//-----------------------------------------------
bool HasOverlap (int Id, double x, double y, double R, int Id2, int Id3)
{
  CMyObject* pObj = NULL;
  int i;
  double x2, y2, x3, y3;

  for (i=0; i<g_nMyObjs; i++){
    pObj = g_MyObj + i;
    if ((pObj->m_Id != Id) && (pObj->m_Id != Id2) && (pObj->m_Id != Id3)){
      if (GetInterPoints( x,y,R, pObj->m_X, pObj->m_Y, pObj->m_Radius, &x2, &y2, &x3, &y3 ) == 2){
        return true;
      }
    }
  }
  return false;
}

//-----------------------------------------------
bool HasJump (double dx2, double dy2, double dx, double dy)
{
  double d = _hypot( dx, dy );
  double d2 = _hypot( dx2, dy2 );
  if (d2 > d){
    return true;
  }
  return false;
}

// returns a number of intersection points
//-----------------------------------------------
int GetInterPoints (double x1, double y1, double R1, double x2, double y2, double R2,
                     double* pOutX1, double* pOutY1, double* pOutX2, double* pOutY2)
{
  double ang, dist, d1, d2, x0, y0, ang2;
  double R1R2;

  dist = _hypot( x1-x2, y1-y2 );
  ang = GetAngle( x1, y1, x2, y2 );
  R1R2 = R1 + R2;
  if (dist > R1R2){
    return 0;
  }
  if (dist == R1R2){
    *pOutX1 = x1 + (R1 * cos(ang));
    *pOutY1 = y1 + (R1 * sin(ang));
    return 1;
  }
  if ((dist + R1) == R2){
    ang = GetAngle( x2, y2, x1, y1 );
    *pOutX1 = x2 + (R2 * cos(ang));
    *pOutY1 = y2 + (R2 * sin(ang));
    return 1;
  }
  if ((dist + R2) == R1){
    *pOutX1 = x1 + (R1 * cos(ang));
    *pOutY1 = y1 + (R1 * sin(ang));
    return 1;
  }
  d1 = (R2*R2 - R1*R1 - dist*dist) / (-2.0 * dist);
  x0 = x1 + (d1 * cos(ang));
  y0 = y1 + (d1 * sin(ang));
  d2 = sqrt( R1*R1 - d1*d1 );
  ang2 = ang + GE_DEG90;
  *pOutX1 = x0 + (d2 * cos(ang2));
  *pOutY1 = y0 + (d2 * sin(ang2));
  *pOutX2 = x0 - (d2 * cos(ang2));
  *pOutY2 = y0 - (d2 * sin(ang2));
  return 2;
}

//-----------------------------------------------
// Angle from point x0,y0 to x1,y1 (0..2PI ccw)
//-----------------------------------------------
double GetAngle (double x0, double y0, double x1, double y1)
{
  double a = x1 - x0;
  double b = y1 - y0;
  if (a == 0.) {
    if (b == 0.){
      return 0.;
    }
    return (b>0.)? GE_PI2 : GE_DEG270;
  }else{
    if (b == 0.){
      return (a>0.)? 0. : GE_PI;
    }
    if (a > 0.){
      if (b > 0.){
        return atan( b / a );
      }else{
        return atan( b / a ) + GE_2PI;
      }
    }else{
      return atan( b / a ) + GE_PI;
    }
  }
}


//-----------------------------------------------
void Report ()
{
  int   x, y, W, H, Style, ExStyle;
  POINT wpt;

  W = 400;
  H = 300;
  ::GetCursorPos( &wpt );
  x = wpt.x - W/2;
  y = wpt.y - H/2;
  ExStyle = WS_EX_DLGMODALFRAME;
  Style = WS_OVERLAPPEDWINDOW | WS_VISIBLE | ES_MULTILINE | ES_WANTRETURN;
  if (::IsWindow( g_hwReport ) == false){
    g_hwReport = ::CreateWindowEx( ExStyle, L"EDIT", L"Report Positions", Style, x,y,W,H, g_hwMain, 0, g_hInst, 0);
    UpdateReport();
  }
}

//-----------------------------------------------
void UpdateReport ()
{
  WCHAR szText[1024], szBuf[64];
  CMyObject* pObj;
  int i;

  if (::IsWindow( g_hwReport )){
    szText[0] = 0;
    for (i=0; i<g_nMyObjs; i++){
      pObj = g_MyObj + i;
      swprintf_s( szBuf, 62, L"Object %d : X=%.2f  Y=%.2f  R=%.1f\r\n", pObj->m_Id, pObj->m_X, pObj->m_Y, pObj->m_Radius );
      wcscat_s( szText, 1020, szBuf );
    }
    ::SendMessage( g_hwReport, WM_SETTEXT, 0, (LPARAM)szText );
  }
}



//-----------------------------------------------
//
//    Class  CMyObject
//  
//-----------------------------------------------
CMyObject::CMyObject ()
{
  m_Id = 0;
  m_X = 0.0;
  m_Y = 0.0;
  m_Radius = 0.0;
  m_bTouch = false;
}
 
//-----------------------------------------------
void CMyObject::Set (int Id, double X, double Y, double R)
{
  m_Id = Id;
  m_X = X;
  m_Y = Y;
  m_Radius = R;
}
//-----------------------------------------------
void CMyObject::Move (double dx, double dy)
{
  m_X += dx;
  m_Y += dy;
}


