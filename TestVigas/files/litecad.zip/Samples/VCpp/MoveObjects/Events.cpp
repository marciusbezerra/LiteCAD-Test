#include "stdafx.h"
#include "MoveObjects.h"

// module variables
static double     _Xprev;
static double     _Yprev;
static double     _CurDX;
static double     _CurDY;
static CMyObject* _pMyObj = NULL;
static bool       _bDown = false;

// popup menu commands
#define CMD_ZOOMEXT    1
#define CMD_POSITIONS  2
#define CMD_INIT       3

//-----------------------------------------------
void __stdcall ProcMouseDown (HANDLE hLcWnd, int Button, int Flags, int Xwin, int Ywin, double Xdrw, double Ydrw)
{
  int    id;
  double x, y;
  HWND   hWnd;
  HANDLE hEnt;

  if (Button == LC_LBUTTON){
    hEnt = lcWndGetEntByPoint( hLcWnd, Xwin, Ywin );
    if (hEnt){
      id = lcPropGetInt( hEnt, LC_PROP_ENT_KEY );
      _pMyObj = GetMyObject( id );
      if (_pMyObj){
        x = _pMyObj->m_X;
        y = _pMyObj->m_Y;
        _Xprev = x;
        _Yprev = y;
        _CurDX = Xdrw - x;
        _CurDY = Ydrw - y;
        lcPropPutInt( 0, LC_PROP_G_CURSORSYS, LC_CURSOR_PAN2 );
        hWnd = (HWND)lcPropGetHandle( hLcWnd, LC_PROP_WND_HWND );
        ::SetCapture( hWnd );
      }
    }else{
      lcPropPutInt( 0, LC_PROP_G_CURSORSYS, LC_CURSOR_ARROW );
      _pMyObj = NULL;
    }
    _bDown = true;
  }
  if (Button == LC_RBUTTON){
    // call popup menu
    POINT wpt;
    HMENU hPopMenu = ::CreatePopupMenu();
    if (hPopMenu){
      ::AppendMenu( hPopMenu, MF_STRING, CMD_ZOOMEXT, L"Zoom Extents" );
      ::AppendMenu( hPopMenu, MF_SEPARATOR, 0,  0 );
      ::AppendMenu( hPopMenu, MF_STRING, CMD_POSITIONS, L"Report Positions" );
      ::AppendMenu( hPopMenu, MF_STRING, CMD_INIT, L"Initial state" );
      // display menu
      wpt.x = Xwin;
      wpt.y = Ywin;
      ::ClientToScreen( g_hwMain, &wpt );
      ::TrackPopupMenu( hPopMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON, wpt.x, wpt.y, 0, g_hwMain, NULL );
    }
    ::DestroyMenu( hPopMenu );
    lcWndRedraw( hLcWnd );
  }
  // don't let LiteCAD to do default action on this event
  lcEventReturnCode( 1 );
}

// Process a command from popup menu
//-----------------------------------------------
bool MyCommand (int Cmd)
{
  switch( Cmd ){
    case CMD_ZOOMEXT:
      lcWndExeCommand( g_hLcWnd, LC_CMD_ZOOM_EXT, 0 );
      return true;
    case CMD_POSITIONS:
      Report();
      return true;
    case CMD_INIT:
      MakePicture( g_hLcDrw, false );
      lcWndRedraw( g_hLcWnd );
      return true;
  }
  return false;
}

//-----------------------------------------------
void __stdcall ProcMouseUp (HANDLE hWnd, int Button, int Flags, int Xwin, int Ywin, double Xdrw, double Ydrw)
{
  if (Button == LC_LBUTTON){
    if (_pMyObj){
      _pMyObj = NULL;
      ::ReleaseCapture();
      lcPropPutInt( 0, LC_PROP_G_CURSORSYS, LC_CURSOR_ARROW );
    }
    _bDown = false;
  }
  // don't let LiteCAD to do default action on this event
  lcEventReturnCode( 1 );
}


//-----------------------------------------------
void __stdcall ProcMouseMove (HANDLE hLcWnd, int Button, int Flags, int Xwin, int Ywin, double Xdrw, double Ydrw)
{
  HANDLE hEnt, hBlock, hDrw;
  int    id;
  double dx, dy, x0, y0, R, dist, ang;
  CMyObject* pObj;

  if (_pMyObj != NULL){
    pObj = GetMyObject( Xdrw, Ydrw );
    if (pObj != _pMyObj){
      _pMyObj = NULL;
      ::ReleaseCapture();
      lcPropPutInt( 0, LC_PROP_G_CURSORSYS, LC_CURSOR_ARROW );
      return;
    }
    lcPropPutInt( 0, LC_PROP_G_CURSORSYS, LC_CURSOR_PAN2 );
    Xdrw -= _CurDX;
    Ydrw -= _CurDY;

    // correct Xdrw, Ydrw by big circle
    R = _pMyObj->m_Radius;
    dist = _hypot( Xdrw, Ydrw ) + R;
    if (dist > BIG_RAD){
      dist = BIG_RAD - R;
      ang = GetAngle( 0, 0, Xdrw, Ydrw );
      Xdrw = dist * cos( ang );
      Ydrw = dist * sin( ang );
    }

    dx = Xdrw - _Xprev;
    dy = Ydrw - _Yprev;
    x0 = _pMyObj->m_X;
    y0 = _pMyObj->m_Y;
    MoveObject( _pMyObj, dx, dy );
    dx = _pMyObj->m_X - x0;
    dy = _pMyObj->m_Y - y0;
    if ((dx != 0.0) || (dy != 0.0)){
      _Xprev += dx;
      _Yprev += dy;
      hDrw = lcPropGetHandle( hLcWnd, LC_PROP_WND_VIEWDRW );
      hBlock = lcPropGetHandle( hLcWnd, LC_PROP_WND_VIEWBLOCK );
      hEnt = lcBlockGetFirstEnt( hBlock );
      while( hEnt != 0){
        id = lcPropGetInt( hEnt, LC_PROP_ENT_KEY );
        if (id == _pMyObj->m_Id){
          lcEntMove( hEnt, dx, dy );
          lcDrwRegenViews( hDrw, hEnt );
        }
        hEnt = lcBlockGetNextEnt( hBlock, hEnt );
      }
      lcWndRedraw( hLcWnd );
    }
    UpdateReport();
  }else{
    pObj = GetMyObject( Xdrw, Ydrw );
    if (pObj && (_bDown == false)){
      lcPropPutInt( 0, LC_PROP_G_CURSORSYS, LC_CURSOR_PAN1 );
    }else{
      lcPropPutInt( 0, LC_PROP_G_CURSORSYS, LC_CURSOR_ARROW );
    }
  }
}
