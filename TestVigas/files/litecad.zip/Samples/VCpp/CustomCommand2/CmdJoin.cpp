#include "stdafx.h"

//-----------------------------------------------
void CmdJoin_Create (HANDLE hLcWnd, int Id, LPCWSTR szName)
{
  lcCreateCommand( hLcWnd, Id, szName, true );
}

//-----------------------------------------------
void CmdJoin_Start (HANDLE hCmd, int Prm)
{
  HANDLE hBlock;
  double Delta = 5.0 * lcPropGetFloat( hCmd, LC_PROP_CMD_PIXELSIZE );

  hBlock = lcPropGetHandle( hCmd, LC_PROP_CMD_BLOCK );
  // rotate selected objects 90 degrees around point X,Y
  lcBlockSelJoin( hBlock, Delta );
  lcCmdRegen( hCmd, 0 );
  lcCmdRedraw( hCmd );
  lcCmdExit();
}
