Description:
Demonstrates how create custom commands.
As opposed to the "CustomCommand" sample, this sample
do not use classes.

Compiler: VS2008 C++ , Win32 project
Author: Oleg Kolbaskin	
Email: ok@kolbasoft.com
