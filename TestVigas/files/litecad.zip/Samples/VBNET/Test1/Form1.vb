﻿
Public Class Form1
    Dim Wfrm As Integer, Hfrm As Integer, Hmenu As Integer
    Dim hLcWnd As Integer, hLcDrw As Integer, hLcProp As Integer, hLcCmd As Integer
    Dim EventMouseDown As F_MOUSEDOWN
    Dim EventPaint As F_PAINT
    Dim EventAddCommand As F_ADDCOMMAND
    Dim EventCmdStart As F_CMD_START
    Dim EventCmdFinish As F_CMD_FINISH
    Dim EventCmdMouseDown As F_CMD_MOUSEDOWN
    Dim EventCmdMouseUp As F_CMD_MOUSEUP
    Dim EventCmdMouseMove As F_CMD_MOUSEMOVE
    Dim EventCmdString As F_CMD_STRING
    Dim EventEntMove As F_ENTMOVE

    Public Const PROP_WIDTH = 200
    Public Const MYCMD_SKETCH = Lcad.LC_CMD_CUSTOM + 1
    Declare Function SetPixel Lib "gdi32" Alias "SetPixel" (ByVal hdc As IntPtr, ByVal x As Integer, ByVal y As Integer, ByVal crColor As Integer) As Integer

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '        Dim hBlock As Integer, hView As Integer, hTStyle As Integer
        Dim hView As Integer
        Lcad.Initialize()
        ' register LiteCAD
        Lcad.PropPutStr(0, LC_PROP_G_REGCODE, "12345")
        ' define event procedures
        EventMouseDown = New F_MOUSEDOWN(AddressOf ProcMouseDown)
        Call Lcad.OnEventMouseDown(EventMouseDown)
        EventPaint = New F_PAINT(AddressOf ProcPaint)
        Call Lcad.OnEventPaint(EventPaint)
        EventAddCommand = New F_ADDCOMMAND(AddressOf ProcAddCommand)
        Call Lcad.OnEventAddCommand(EventAddCommand)
        EventCmdStart = New F_CMD_START(AddressOf ProcCmdStart)
        Call Lcad.OnEventCmdStart(EventCmdStart)
        EventCmdFinish = New F_CMD_FINISH(AddressOf ProcCmdFinish)
        Call Lcad.OnEventCmdFinish(EventCmdFinish)
        EventCmdMouseDown = New F_CMD_MOUSEDOWN(AddressOf ProcCmdMouseDown)
        Call Lcad.OnEventCmdMouseDown(EventCmdMouseDown)
        EventCmdMouseUp = New F_CMD_MOUSEUP(AddressOf ProcCmdMouseUp)
        Call Lcad.OnEventCmdMouseUp(EventCmdMouseUp)
        EventCmdMouseMove = New F_CMD_MOUSEMOVE(AddressOf ProcCmdMouseMove)
        Call Lcad.OnEventCmdMouseMove(EventCmdMouseMove)
        EventCmdString = New F_CMD_STRING(AddressOf ProcCmdString)
        Call Lcad.OnEventCmdString(EventCmdString)

        'EventEntMove = New F_ENTMOVE(AddressOf ProcEntMove)
        'Call Lcad.OnEventEntMove(EventEntMove)

        ' create CAD window and a drawing
        Hmenu = MenuStrip1.Height
        hLcWnd = Lcad.CreateWindow(Handle, LC_WS_DEFAULT, 0, 0, 100, 100)
        Lcad.WndResize(hLcWnd, 0, 0, 100, 100)
        hLcDrw = Lcad.CreateDrawing()
        Lcad.DrwNew(hLcDrw, "", hLcWnd)
        ' Properties window
        hLcProp = Lcad.CreatePropwin(Handle, 0, 0, 100, 100)
        Lcad.WndSetPropwin(hLcWnd, hLcProp)

        hLcCmd = Lcad.CreateCmdwin(Handle, 8, 8, 400, 400)
        Lcad.WndSetCmdwin(hLcWnd, hLcCmd)

        ' add some graphics
        '        AddSomeGraphics()

        ' hide grid
        hView = Lcad.PropGetHandle(hLcDrw, LC_PROP_DRW_VIEW_MODEL)
        Lcad.PropPutBool(hView, LC_PROP_VIEW_GRID, False)
        ' Zoom extents
        Lcad.WndExeCommand(hLcWnd, LC_CMD_ZOOM_EXT, 0)

        Lcad.PropwinResize(hLcProp, 0, Hmenu, PROP_WIDTH, Hfrm - Hmenu)
        Lcad.WndResize(hLcWnd, PROP_WIDTH, Hmenu, Wfrm - PROP_WIDTH, Hfrm - Hmenu - 100)
        Lcad.CmdwinResize(hLcCmd, PROP_WIDTH, Hfrm - Hmenu - 75, Wfrm - PROP_WIDTH, 100)

        '        Lcad.PropPutStr(0, LC_PROP_G_ICON16, "D:\!OK\Projects\LiteCAD\_Final\Samples\VBNET\Test1\Resources\LcadIcon.ico")
    End Sub

    Private Sub Form1_Resize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        Lcad.GetClientSize(Handle, Wfrm, Hfrm)
        If hLcWnd <> 0 Then
            Lcad.PropwinResize(hLcProp, 0, Hmenu, PROP_WIDTH, Hfrm - Hmenu)
            Lcad.WndResize(hLcWnd, PROP_WIDTH, Hmenu, Wfrm - PROP_WIDTH, Hfrm - Hmenu)
            Lcad.WndRedraw(hLcWnd)
        End If
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click
        Lcad.DrwLoad(hLcDrw, "<Dialog>", Handle, hLcWnd)
    End Sub

    Private Sub NewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripMenuItem.Click
        Lcad.DrwNew(hLcDrw, "", hLcWnd)
    End Sub

    Private Sub LayersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LayersToolStripMenuItem.Click
        Lcad.WndExeCommand(hLcWnd, LC_CMD_LAYER, 0)
    End Sub

    Private Sub LinetypesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinetypesToolStripMenuItem.Click
        Lcad.WndExeCommand(hLcWnd, LC_CMD_LINETYPE, 0)
    End Sub

    Private Sub TextStylesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextStylesToolStripMenuItem.Click
        Lcad.WndExeCommand(hLcWnd, LC_CMD_TEXTSTYLE, 0)
    End Sub

    Private Sub BlocksToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlocksToolStripMenuItem.Click
        Lcad.WndExeCommand(hLcWnd, LC_CMD_BLOCKS, 0)
    End Sub

    Private Sub PointToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PointToolStripMenuItem.Click
        Lcad.WndExeCommand(hLcWnd, LC_CMD_POINT, 0)
    End Sub

    Private Sub LineToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LineToolStripMenuItem.Click
        Lcad.WndExeCommand(hLcWnd, LC_CMD_LINE, 0)
    End Sub

    Private Sub PolylineToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PolylineToolStripMenuItem.Click
        Lcad.WndExeCommand(hLcWnd, LC_CMD_POLYLINE, 0)
    End Sub

    Private Sub CircleToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CircleToolStripMenuItem.Click
        Lcad.WndExeCommand(hLcWnd, LC_CMD_CIRCLE, 0)
    End Sub

    Private Sub TextToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextToolStripMenuItem.Click
        Lcad.WndExeCommand(hLcWnd, LC_CMD_TEXT, 0)
    End Sub

    Private Sub CreateDrawingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateDrawingToolStripMenuItem.Click
        Dim hLayer As Integer, hBlock As Integer, hView As Integer, hEnt As Integer, hPline As Integer
        Dim sText As String
        ' clear a drawing
        Lcad.DrwNew(hLcDrw, "", hLcWnd)
        ' get "Model Space" block
        hBlock = Lcad.PropGetHandle(hLcDrw, LC_PROP_DRW_BLOCK_MODEL)
        ' add lines
        Lcad.BlockAddLine(hBlock, 0, 0, 100, 100)
        Lcad.BlockAddLine(hBlock, 50, 0, 100, 50)
        ' add circle
        hEnt = Lcad.BlockAddCircle(hBlock, 60, 40, 10, 0)
        ' change the circle's color (use RGB)
        Lcad.PropPutStr(hEnt, Lcad.LC_PROP_ENT_COLOR, "128,200,250")
        ' add text
        Lcad.BlockAddText2(hBlock, "The Text", 0, 50, LC_TA_LEFBOT, 5, 0.8, 45 * LC_DEG_TO_RAD, 0)
        ' set current color (use AutoCAD color index)
        Lcad.PropPutStr(hLcDrw, LC_PROP_DRW_COLOR, "45")
        ' add text
        sText = Lcad.PropGetStr(0, Lcad.LC_PROP_G_DIRDLL)
        Lcad.BlockAddText2(hBlock, sText, 0, 20, LC_TA_LEFBOT, 5, 0.8, 0, 0)
        ' set current color "ByLayer"
        Lcad.PropPutStr(hLcDrw, LC_PROP_DRW_COLOR, "ByLayer")
        ' add new layer
        hLayer = Lcad.DrwAddLayer(hLcDrw, "Vertices", "green", 0, LC_LWEIGHT_000)
        ' set current layer
        Lcad.PropPutHandle(hLcDrw, LC_PROP_DRW_LAYER, hLayer)
        ' add polyline
        hPline = Lcad.BlockAddPolyline(hBlock, LC_PLFIT_QUAD, True, False)
        Lcad.PlineAddVer(hPline, 0, 20, 80)
        Lcad.PlineAddVer(hPline, 0, 30, 90)
        Lcad.PlineAddVer(hPline, 0, 50, 70)
        Lcad.PlineAddVer(hPline, 0, 33, 63)
        Lcad.PlineAddVer(hPline, 0, 20, 50)

        Lcad.DrwRegenViews(hLcDrw, 0)
        ' hide grid
        hView = Lcad.PropGetHandle(hLcDrw, LC_PROP_DRW_VIEW_MODEL)
        Lcad.PropPutBool(hView, LC_PROP_VIEW_GRID, False)
        ' Zoom extents
        Lcad.WndExeCommand(hLcWnd, Lcad.LC_CMD_ZOOM_EXT, 0)
    End Sub

    Private Sub ProcMouseDown(ByVal hLcWnd As Integer, ByVal Button As Integer, ByVal Flags As Integer, ByVal Xwin As Integer, ByVal Ywin As Integer, ByVal X As Double, ByVal Y As Double)
        Dim hEnt As Integer, hView As Integer
        Dim Color As String
        'Dim Xw As Integer, Yw As Integer
        'Dim Xd As Double, Yd As Double

        If Button = LC_LBUTTON And Flags = LC_CTRL Then

            'Lcad.WndGetCursorCoord(hLcWnd, Xw, Yw, Xd, Yd)

            hEnt = Lcad.WndGetEntByPoint(hLcWnd, Xwin, Ywin)
            If hEnt <> 0 Then
                Color = Lcad.PropGetStr(hEnt, LC_PROP_ENT_COLOR)
                If Color = "2" Then
                    Lcad.PropPutStr(hEnt, LC_PROP_ENT_COLOR, "4")   ' cyan
                Else
                    Lcad.PropPutStr(hEnt, LC_PROP_ENT_COLOR, "2")   ' yellow
                End If
                hView = Lcad.PropGetHandle(hLcWnd, LC_PROP_WND_VIEW)
                Lcad.ViewRegen(hView, hEnt)
                Lcad.WndRedraw(hLcWnd)
            End If
            ' Disable LiteCAD default action
            Lcad.EventReturnCode(1)
        End If
    End Sub
    Private Sub ProcPaint(ByVal hLcWnd As Integer, ByVal hView As Integer, ByVal Mode As Integer, ByVal hDC As Integer, ByVal Left As Integer, ByVal Top As Integer, ByVal Right As Integer, ByVal Bottom As Integer)
        '        Dim wx As Integer, wy As Integer
        If Mode = 1 Then
            '            Lcad.CoordDrwToWnd(hLcWnd, 10, 20, wx, wy)
            '            SetPixel(hDC, wx, wy, ColorTranslator.ToWin32(Color.Yellow))
            'TestPaint(hLcWnd)
        End If
    End Sub

    Private Sub SketchToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SketchToolStripMenuItem.Click
        Lcad.WndExeCommand(hLcWnd, MYCMD_SKETCH, 0)
    End Sub

    Private Sub ProcAddCommand(ByVal hLcWnd As Integer)
        Lcad.CreateCommand(hLcWnd, MYCMD_SKETCH, "SKETCH", False)
    End Sub
    Private Sub ProcCmdStart(ByVal hCmd As Integer, ByVal Prm As Integer)
        Dim Id As Integer
        Id = Lcad.PropGetInt(hCmd, LC_PROP_CMD_ID)
        If Id = MYCMD_SKETCH Then
            Lcad.PropPutInt(hCmd, LC_PROP_CMD_INT0, 0)   ' do not draw
            Lcad.PropPutHandle(hCmd, LC_PROP_CMD_HAND0, 0) ' polyline
        End If
    End Sub
    Private Sub ProcCmdFinish(ByVal hCmd As Integer)
        Dim Id As Integer
        Id = Lcad.PropGetInt(hCmd, LC_PROP_CMD_ID)
        If Id = MYCMD_SKETCH Then

        End If
    End Sub
    Private Sub ProcCmdMouseDown(ByVal hCmd As Integer, ByVal Button As Integer, ByVal Flags As Integer, ByVal Xwin As Integer, ByVal Ywin As Integer, ByVal X As Double, ByVal Y As Double)
        Dim Id As Integer
        Dim hBlock As Integer, hPline As Integer

        Id = Lcad.PropGetInt(hCmd, LC_PROP_CMD_ID)
        If Id = MYCMD_SKETCH Then
            If Button = LC_LBUTTON Then
                hBlock = Lcad.PropGetHandle(hCmd, LC_PROP_CMD_BLOCK)
                hPline = Lcad.BlockAddPolyline(hBlock, 0, False, False)
                Lcad.PropPutHandle(hCmd, LC_PROP_CMD_HAND0, hPline)  ' polyline
                Lcad.PropPutInt(hCmd, LC_PROP_CMD_INT0, 1)   ' draw
            ElseIf Button = LC_RBUTTON Then
                Lcad.CmdExit()  ' exit command
            End If
        End If
    End Sub
    Private Sub ProcCmdMouseUp(ByVal hCmd As Integer, ByVal Button As Integer, ByVal Flags As Integer, ByVal Xwin As Integer, ByVal Ywin As Integer, ByVal X As Double, ByVal Y As Double)
        Dim Id As Integer
        Id = Lcad.PropGetInt(hCmd, LC_PROP_CMD_ID)
        If Id = MYCMD_SKETCH Then
            If Button = LC_LBUTTON Then
                Lcad.PropPutInt(hCmd, LC_PROP_CMD_INT0, 0)  ' do not draw
            End If
        End If
    End Sub
    Private Sub ProcCmdMouseMove(ByVal hCmd As Integer, ByVal hDC As Integer, ByVal Flags As Integer, ByVal Xwin As Integer, ByVal Ywin As Integer, ByVal X As Double, ByVal Y As Double)
        Dim Id As Integer
        Dim hPline As Integer, bDraw As Integer

        Id = Lcad.PropGetInt(hCmd, LC_PROP_CMD_ID)
        If Id = MYCMD_SKETCH Then
            bDraw = Lcad.PropGetInt(hCmd, LC_PROP_CMD_INT0)
            If bDraw = 1 Then
                hPline = Lcad.PropGetHandle(hCmd, LC_PROP_CMD_HAND0)
                Lcad.PlineAddVer(hPline, 0, X, Y)
                Lcad.CmdRegen(hCmd, hPline)
                Lcad.CmdRedraw(hCmd)
            End If
        End If
    End Sub
    Private Sub ProcCmdString(ByVal hCmd As Integer, ByVal szStr As String)
        Dim Id As Integer
        Dim Str2 As String

        Id = Lcad.PropGetInt(hCmd, LC_PROP_CMD_ID)
        If Id = MYCMD_SKETCH Then
          Str2 = Lcad.PropGetStr(hCmd, LC_PROP_CMD_MSGSTR)
        End If
    End Sub
    Private Sub AddSomeGraphics()
        Dim hBlock As Integer, hTStyle As Integer
        hBlock = Lcad.PropGetHandle(hLcDrw, LC_PROP_DRW_BLOCK_MODEL)
        hTStyle = Lcad.DrwAddTextStyle(hLcDrw, "New Style", "Complex")
        Lcad.PropPutHandle(hLcDrw, LC_PROP_DRW_TEXTSTYLE, hTStyle)  ' set current style
        Lcad.BlockAddText2(hBlock, "Hello World!", 0, 0, LC_TA_CENTER, 5, 1.5, 45 * LC_DEG_TO_RAD, 0)
        Lcad.BlockAddCircle(hBlock, 0, 0, 50, False)
        Lcad.DrwRegenViews(hLcDrw, 0)
    End Sub
    Private Sub TestPaint(ByVal hLcWnd As Integer)
        ' initialize 
        Lcad.PaintBegin(hLcWnd)
        ' draw  line
        Lcad.PaintSetPen(LC_PS_DOT, 1, 0, 200, 100)
        Lcad.PaintLine(10, 20, 30, -20)
        ' draw points
        Lcad.PaintSetPen(LC_PS_SOLID, 1, 0, 255, 127)
        Lcad.PaintPoint(30, 0, LC_POINT_PLUS Or LC_POINT_CIRCLE, -1)
        Lcad.PaintPoint(30, 5, LC_POINT_PLUS Or LC_POINT_CIRCLE, -1)
        Lcad.PaintPoint(30, 10, LC_POINT_PLUS Or LC_POINT_CIRCLE, -1)
        Lcad.PaintPixel(40, 0, 0, 255, 0, 255)
        Lcad.PaintPixel(40, 5, 1, 255, 0, 255)
        Lcad.PaintPixel(40, 10, 2, 255, 0, 255)
        ' draw circles (non-filled, filled, filled & border)
        Lcad.PaintSetBrush(100, 100, 0)
        Lcad.PaintSetPen(LC_PS_SOLID, 1, 0, 255, 255)
        Lcad.PaintCircle(0, 0, 10, False, False)
        Lcad.PaintCircle(0, 20, 10, True, False)
        Lcad.PaintCircle(0, 40, 10, True, True)
        ' draw polylines (non-filled, filled, filled & border)
        Lcad.PaintPlineVer(20, 10)
        Lcad.PaintPlineVer(20, 30)
        Lcad.PaintPlineVer(40, 20)
        Lcad.PaintPline(True, True, True)
        Lcad.PaintPlineVer(50, 10)
        Lcad.PaintPlineVer(50, 30)
        Lcad.PaintPlineVer(70, 20)
        Lcad.PaintPline(True, True, False)
        Lcad.PaintPlineVer(80, 10)
        Lcad.PaintPlineVer(80, 30)
        Lcad.PaintPlineVer(100, 20)
        Lcad.PaintPline(True, False, True)
        ' draw line
        Lcad.PaintSetPen(LC_PS_SOLID, 1, 255, 0, 0)
        Lcad.PaintLine(0, 0, 10, 20)
        ' draw arc
        Lcad.PaintArc(0, 0, 30, 45 * LC_DEG_TO_RAD, 90 * LC_DEG_TO_RAD)
        ' draw text
        Lcad.PaintText("Hello World!", 0, 30, 0)
        Lcad.PaintSetFont("Arial", -25, 45 * LC_DEG_TO_RAD, False, False, False, False)
        Lcad.PaintSetTextColor(0, 255, 0)
        Lcad.PaintText("Non-scalable text, size = 25 pixels", 0, 40, LC_WTA_CENTER Or LC_WTA_BASELINE)
        Lcad.PaintPixel(0, 40, 2, 255, 0, 255)
        Lcad.PaintSetFont("Times New Roman", 5, -30 * LC_DEG_TO_RAD, False, True, False, False)
        Lcad.PaintSetTextColor(0, 155, 255)
        Lcad.PaintText("Text, centered at X=40, Y=30", 40, 30, LC_WTA_CENTER Or LC_WTA_BASELINE)
        Lcad.PaintPixel(40, 30, 2, 255, 0, 255)
        ' finish
        Lcad.PaintEnd()
    End Sub
    Private Sub ProcEntMove(ByVal di As Integer, ByVal ddx As Double, ByVal ddy As Double, ByVal ddr As Integer)
        Debug.Print(ddx, ddy)
        'Label1.Text = ddx
    End Sub

End Class

