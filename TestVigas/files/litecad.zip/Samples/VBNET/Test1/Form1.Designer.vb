﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FormatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LayersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LinetypesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TextStylesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BlocksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DrawToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PointToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PolylineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CircleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TextToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TestToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CreateDrawingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SketchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.FormatToolStripMenuItem, Me.DrawToolStripMenuItem, Me.TestToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(949, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.OpenToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.OpenToolStripMenuItem.Text = "Open..."
        '
        'FormatToolStripMenuItem
        '
        Me.FormatToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LayersToolStripMenuItem, Me.LinetypesToolStripMenuItem, Me.TextStylesToolStripMenuItem, Me.BlocksToolStripMenuItem})
        Me.FormatToolStripMenuItem.Name = "FormatToolStripMenuItem"
        Me.FormatToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
        Me.FormatToolStripMenuItem.Text = "Format"
        '
        'LayersToolStripMenuItem
        '
        Me.LayersToolStripMenuItem.Name = "LayersToolStripMenuItem"
        Me.LayersToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.LayersToolStripMenuItem.Text = "Layers..."
        '
        'LinetypesToolStripMenuItem
        '
        Me.LinetypesToolStripMenuItem.Name = "LinetypesToolStripMenuItem"
        Me.LinetypesToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.LinetypesToolStripMenuItem.Text = "Linetypes..."
        '
        'TextStylesToolStripMenuItem
        '
        Me.TextStylesToolStripMenuItem.Name = "TextStylesToolStripMenuItem"
        Me.TextStylesToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.TextStylesToolStripMenuItem.Text = "Text styles..."
        '
        'BlocksToolStripMenuItem
        '
        Me.BlocksToolStripMenuItem.Name = "BlocksToolStripMenuItem"
        Me.BlocksToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.BlocksToolStripMenuItem.Text = "Blocks..."
        '
        'DrawToolStripMenuItem
        '
        Me.DrawToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PointToolStripMenuItem, Me.LineToolStripMenuItem, Me.PolylineToolStripMenuItem, Me.CircleToolStripMenuItem, Me.TextToolStripMenuItem})
        Me.DrawToolStripMenuItem.Name = "DrawToolStripMenuItem"
        Me.DrawToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.DrawToolStripMenuItem.Text = "Draw"
        '
        'PointToolStripMenuItem
        '
        Me.PointToolStripMenuItem.Name = "PointToolStripMenuItem"
        Me.PointToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.PointToolStripMenuItem.Text = "Point"
        '
        'LineToolStripMenuItem
        '
        Me.LineToolStripMenuItem.Name = "LineToolStripMenuItem"
        Me.LineToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.LineToolStripMenuItem.Text = "Line"
        '
        'PolylineToolStripMenuItem
        '
        Me.PolylineToolStripMenuItem.Name = "PolylineToolStripMenuItem"
        Me.PolylineToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.PolylineToolStripMenuItem.Text = "Polyline"
        '
        'CircleToolStripMenuItem
        '
        Me.CircleToolStripMenuItem.Name = "CircleToolStripMenuItem"
        Me.CircleToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.CircleToolStripMenuItem.Text = "Circle"
        '
        'TextToolStripMenuItem
        '
        Me.TextToolStripMenuItem.Name = "TextToolStripMenuItem"
        Me.TextToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.TextToolStripMenuItem.Text = "Text"
        '
        'TestToolStripMenuItem
        '
        Me.TestToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CreateDrawingToolStripMenuItem, Me.SketchToolStripMenuItem})
        Me.TestToolStripMenuItem.Name = "TestToolStripMenuItem"
        Me.TestToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.TestToolStripMenuItem.Text = "Test"
        '
        'CreateDrawingToolStripMenuItem
        '
        Me.CreateDrawingToolStripMenuItem.Name = "CreateDrawingToolStripMenuItem"
        Me.CreateDrawingToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.CreateDrawingToolStripMenuItem.Text = "Create drawing"
        '
        'SketchToolStripMenuItem
        '
        Me.SketchToolStripMenuItem.Name = "SketchToolStripMenuItem"
        Me.SketchToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.SketchToolStripMenuItem.Text = "Sketch"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(949, 654)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Test 1 for LiteCAD DLL"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormatToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LayersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LinetypesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextStylesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BlocksToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DrawToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PointToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LineToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PolylineToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CircleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TestToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreateDrawingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SketchToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
