﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace CustomCommand
{
  public partial class Form1 : Form
  {
    int m_hLcWnd, m_hDrw;
    int m_hLcCmd, m_hLcProp;
    int m_MenuSize = 50; //24;
    int m_PropWidth = 200;
    int m_CmdHeight = 100;
    const int CMD_MYLINES = Lcad.LC_CMD_CUSTOM + 1;
    F_ADDCOMMAND    EventAddCommand;
    F_CMD_START     EventCmdStart;
    F_CMD_FINISH    EventCmdFinish;
    F_CMD_MOUSEDOWN EventCmdMouseDown;
    F_CMD_MOUSEUP   EventCmdMouseUp;
    F_CMD_MOUSEMOVE EventCmdMouseMove;
    F_CMD_STRING    EventCmdString;
    F_GETPOINT      EventGetPoint;

    public Form1()
    {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
//      int x, y, w, h;

      Lcad.PropPutStr(0, Lcad.LC_PROP_G_REGCODE, "12345");
      Lcad.Initialize();

      // define event procedures
      EventAddCommand   = new F_ADDCOMMAND(Form1.ProcAddCommand);
      EventCmdStart     = new F_CMD_START(Form1.ProcCmdStart);
      EventCmdFinish    = new F_CMD_FINISH(Form1.ProcCmdFinish);
      EventCmdMouseDown = new F_CMD_MOUSEDOWN(Form1.ProcCmdMouseDown);
      EventCmdMouseUp   = new F_CMD_MOUSEUP(Form1.ProcCmdMouseUp);
      EventCmdMouseMove = new F_CMD_MOUSEMOVE(Form1.ProcCmdMouseMove);
      EventCmdString    = new F_CMD_STRING(Form1.ProcCmdString);
      EventGetPoint = new F_GETPOINT(Form1.ProcGetPoint);
      Lcad.OnEventAddCommand(EventAddCommand);
      Lcad.OnEventCmdStart(EventCmdStart);
      Lcad.OnEventCmdFinish(EventCmdFinish);
      Lcad.OnEventCmdMouseDown(EventCmdMouseDown);
      Lcad.OnEventCmdMouseUp(EventCmdMouseUp);
      Lcad.OnEventCmdMouseMove(EventCmdMouseMove);
      Lcad.OnEventCmdString(EventCmdString);
      Lcad.OnEventGetPoint(EventGetPoint);

      // create CAD window
      m_hLcWnd = Lcad.CreateWindow(Handle, 0, 0, 0, 300, 300);

      // create Command line window
      m_hLcCmd = Lcad.CreateCmdwin(Handle, 0, 0, 300, 300);
      Lcad.WndSetCmdwin(m_hLcWnd, m_hLcCmd);

      // create Properties window
      m_hLcProp = Lcad.CreatePropwin(Handle, 0, 0, 300, 300);
      Lcad.WndSetPropwin(m_hLcWnd, m_hLcProp);

      // create a drawing object
      m_hDrw = Lcad.CreateDrawing();
      Lcad.DrwNew(m_hDrw, "", m_hLcWnd);

      UpdateLcadSize();
      Lcad.WndSetFocus(m_hLcWnd);
    }

    private void UpdateLcadSize()
    {
      int x, y, w, h;
      int MainW, MainH;

      Lcad.GetClientSize(Handle, out MainW, out MainH);
      // CAD window
      x = m_PropWidth;
      y = m_MenuSize;
      w = MainW - m_PropWidth;
      h = MainH - m_MenuSize - m_CmdHeight - 1;
      Lcad.WndResize(m_hLcWnd, x, y, w, h);

      // Command line window
      x = m_PropWidth;
      y = MainH - m_CmdHeight;
      w = MainW - m_PropWidth;
      h = m_CmdHeight;
      Lcad.CmdwinResize(m_hLcCmd, x, y, w, h);

      // Properties window
      x = 0;
      y = m_MenuSize;
      w = m_PropWidth;
      h = MainH - m_MenuSize;
      Lcad.PropwinResize(m_hLcProp, x, y, w, h);
    }

    private void Form1_Resize(object sender, EventArgs e)
    {
      UpdateLcadSize();
    }

    private void Form1_FormClosed(object sender, FormClosedEventArgs e)
    {
      Lcad.Uninitialize(false);
    }

    private void newToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Lcad.DrwNew(m_hDrw, "", m_hLcWnd);
    }

    private void openToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Lcad.DrwLoad(m_hDrw, "<Dialog>", Handle, m_hLcWnd);
    }

    private void lineToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Lcad.WndExeCommand(m_hLcWnd, CMD_MYLINES, 0);
    }

    private void lineToolStripMenuItem1_Click(object sender, EventArgs e)
    {
      Lcad.WndExeCommand(m_hLcWnd, Lcad.LC_CMD_LINE, 0);
    }



    public static void ProcAddCommand (int hLcWnd)
    {
      Lcad.CreateCommand(hLcWnd, CMD_MYLINES, "MYLINES", false);
    }

    public static void ProcCmdStart (int hCmd, int Prm)
    {
      int Id = Lcad.PropGetInt(hCmd, Lcad.LC_PROP_CMD_ID);
      switch( Id )
      {
        case CMD_MYLINES: Cmd_MyLines_Start( hCmd, Prm ); break;
      }
    }

    public static void ProcCmdFinish (int hCmd)
    {
      int Id = Lcad.PropGetInt(hCmd, Lcad.LC_PROP_CMD_ID);
      switch( Id )
      {
        case CMD_MYLINES: Cmd_MyLines_Finish( hCmd ); break;
      }
    }

    public static void ProcCmdString (int hCmd, string szStr)
    {
      int Id = Lcad.PropGetInt(hCmd, Lcad.LC_PROP_CMD_ID);
      switch( Id )
      {
        case CMD_MYLINES: Cmd_MyLines_String( hCmd, szStr ); break;
      }
    }

    public static void ProcCmdMouseDown (int hCmd, int Button, int Flags, int Xwin, int Ywin, double X, double Y)
    {
      int Id = Lcad.PropGetInt(hCmd, Lcad.LC_PROP_CMD_ID);
      switch( Id )
      {
        case CMD_MYLINES: Cmd_MyLines_MouseDown( hCmd, Button, Flags, Xwin, Ywin, X, Y ); break;
      }
    }

    public static void ProcCmdMouseUp (int hCmd, int Button, int Flags, int Xwin, int Ywin, double X, double Y)
    {
      int Id = Lcad.PropGetInt(hCmd, Lcad.LC_PROP_CMD_ID);
      switch (Id)
      {
        case CMD_MYLINES: Cmd_MyLines_MouseUp(hCmd, Button, Flags, Xwin, Ywin, X, Y); break;
      }
    }

    public static void ProcCmdMouseMove (int hCmd, IntPtr hDC, int Flags, int Xwin, int Ywin, double X, double Y)
    {
      int Id = Lcad.PropGetInt(hCmd, Lcad.LC_PROP_CMD_ID);
      switch (Id)
      {
        case CMD_MYLINES: Cmd_MyLines_MouseMove( hCmd, hDC, Flags, Xwin, Ywin, X, Y); break;
      }
    }





    private static void Cmd_MyLines_Start (int hCmd, int Prm)
    {
      int OSnapMode;
      bool bOSnapOn;

      Lcad.PropPutInt(hCmd, Lcad.LC_PROP_CMD_STEP, 1);
      // save current snap mode
      bOSnapOn = Lcad.PropGetBool(hCmd, Lcad.LC_PROP_CMD_OSNAP);
      OSnapMode = Lcad.PropGetInt(hCmd, Lcad.LC_PROP_CMD_OSNAP);
      Lcad.PropPutInt(hCmd, Lcad.LC_PROP_CMD_INT0, bOSnapOn?1:0);
      Lcad.PropPutInt(hCmd, Lcad.LC_PROP_CMD_INT1, OSnapMode);
      // set snap mode for the command
      Lcad.PropPutBool(hCmd, Lcad.LC_PROP_CMD_OSNAP, true);
      Lcad.PropPutInt(hCmd, Lcad.LC_PROP_CMD_OSNAP, Lcad.LC_SNAP_ENDPOINT);
      Lcad.CmdPrompt( hCmd, "Input first point:" );
    }

    private static void Cmd_MyLines_Finish(int hCmd)
    {
      bool bOSnapOn;
      int  OSnapMode;

      // restore original snap modes
      bOSnapOn = (Lcad.PropGetInt(hCmd, Lcad.LC_PROP_CMD_INT0)==0)?false:true;
      OSnapMode = Lcad.PropGetInt(hCmd, Lcad.LC_PROP_CMD_INT1);
      Lcad.PropPutBool(hCmd, Lcad.LC_PROP_CMD_OSNAP, bOSnapOn);
      Lcad.PropPutInt(hCmd, Lcad.LC_PROP_CMD_OSNAP, OSnapMode);
    }

    private static void Cmd_MyLines_String(int hCmd, string szStr)
    {
        string STR1;
        STR1 = Lcad.PropGetStr(hCmd, Lcad.LC_PROP_CMD_STR);
    }

    private static void Cmd_MyLines_MouseDown(int hCmd, int Button, int Flags, int Xwin, int Ywin, double X, double Y)
    {
      double X0, Y0;
      int Step;

      if (Button == Lcad.LC_LBUTTON)
      {
        Step = Lcad.PropGetInt( hCmd, Lcad.LC_PROP_CMD_STEP );
        switch( Step ){
          case 1:
            Lcad.PropPutInt( hCmd, Lcad.LC_PROP_CMD_STEP, 2 );
            Lcad.PropPutFloat( hCmd, Lcad.LC_PROP_CMD_FLOAT0, X );
            Lcad.PropPutFloat( hCmd, Lcad.LC_PROP_CMD_FLOAT1, Y );
            Lcad.CmdPrompt( hCmd, "Input second point:" );
            Lcad.PropPutStr(hCmd, Lcad.LC_PROP_CMD_STR, "MouseDown");
            break;
          case 2:
            X0 = Lcad.PropGetFloat( hCmd, Lcad.LC_PROP_CMD_FLOAT0 );
            Y0 = Lcad.PropGetFloat( hCmd, Lcad.LC_PROP_CMD_FLOAT1 );
            if (Cmd_MyLines_AddLine(hCmd, X0, Y0, X, Y)){
              Lcad.PropPutInt(hCmd, Lcad.LC_PROP_CMD_STEP, 1);
              Lcad.CmdPrompt( hCmd, "Input first point:" );
            }else{
              Lcad.CmdPrompt( hCmd, "Input second point:" );
            }
            break;
        }
      }else{
        if (Button == Lcad.LC_RBUTTON)
        {
          Lcad.CmdExit();  // exit command
        }
      }
    }

    private static void Cmd_MyLines_MouseUp(int hCmd, int Button, int Flags, int Xwin, int Ywin, double X, double Y)
    {
    }

    private static void Cmd_MyLines_MouseMove(int hCmd, IntPtr hDC, int Flags, int Xwin, int Ywin, double X, double Y)
    {
      double X0, Y0;
      int Step;

      Step = Lcad.PropGetInt(hCmd, Lcad.LC_PROP_CMD_STEP);
      switch( Step ){
        case 1:
          Lcad.CmdPrompt(hCmd, "First point");
          break;
        case 2:
          Lcad.CmdPrompt(hCmd, "Second point");
          X0 = Lcad.PropGetFloat(hCmd, Lcad.LC_PROP_CMD_FLOAT0);
          Y0 = Lcad.PropGetFloat(hCmd, Lcad.LC_PROP_CMD_FLOAT1);
          Lcad.CmdDrawLine(hCmd, X0, Y0, X, Y);
          break;
      }
    }

    private static bool Cmd_MyLines_AddLine(int hCmd, double x0, double y0, double x1, double y1)
    {
      int hBlock, hLine;
      double dx, dy;

      dx = x1 - x0;
      dy = y1 - y0;
      if (dx!=0.0 || dy!=0.0){
        hBlock = Lcad.PropGetHandle( hCmd, Lcad.LC_PROP_CMD_BLOCK );
        hLine = Lcad.BlockAddLine( hBlock, x0, y0, x1, y1 );
        Lcad.CmdRegen( hCmd, hLine );
        return true;
      }
      return false;
    }

    private void adLineToolStripMenuItem_Click(object sender, EventArgs e)
    {
      double x1, y1;
      double x2, y2;
      int hBlock = Lcad.DrwGetFirstObject( m_hDrw, Lcad.LC_OBJ_BLOCK );
      if (Lcad.WndGetPoint(m_hLcWnd, "Enter starting point: ", Lcad.LC_SNAP_INTER, 0, out x1, out y1))
      {
        if (Lcad.WndGetPoint(m_hLcWnd, "Enter end point: ", Lcad.LC_SNAP_INTER, 1, out x2, out y2))
        {
          Lcad.BlockAddLine(hBlock, x1, y1, x2, y2);
          Lcad.DrwRegenViews(m_hDrw, 0);
          Lcad.WndSetFocus(m_hLcWnd);
        }
      }
    }

    private static void ProcGetPoint(int hLcWnd, int hView, int Index, double X, double Y)
    {
      double x0, y0;
      if (Index == 1)
      {
        Lcad.WndGetPointBuf(hLcWnd, 0, out x0, out y0);
        Lcad.ViewDrawMarker(hView, x0, y0);
        Lcad.ViewDrawLine(hView, x0, y0, X, Y);
      }
    }

    private void polylineToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Lcad.WndExeCommand(m_hLcWnd, Lcad.LC_CMD_POLYLINE, 0);
    }

    private void circleToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Lcad.WndExeCommand(m_hLcWnd, Lcad.LC_CMD_CIRCLE, 0);
    }

    private void arcToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Lcad.WndExeCommand(m_hLcWnd, Lcad.LC_CMD_ARC, 0);
    }

    private void textToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Lcad.WndExeCommand(m_hLcWnd, Lcad.LC_CMD_TEXT, 0);
    }

    private void toolStripButton1_Click(object sender, EventArgs e)
    {
      Lcad.WndExeCommand(m_hLcWnd, Lcad.LC_CMD_LINE, 0);
    }

    private void toolStripButton2_Click(object sender, EventArgs e)
    {
      Lcad.WndExeCommand(m_hLcWnd, Lcad.LC_CMD_CIRCLE, 0);
    }

    private void toolStrip1_Enter(object sender, EventArgs e)
    {
      Lcad.WndSetFocus(m_hLcWnd);

    }

    private void loadFileToolStripMenuItem_Click(object sender, EventArgs e)
    {
//      Lcad.DrwLoad(m_hDrw, "d:\\Test.dwg", new System.IntPtr(), m_hLcWnd);
        string strText;
        strText = Lcad.PropGetStr(0, Lcad.LC_PROP_G_DIRDLL);
    }



  }
}




