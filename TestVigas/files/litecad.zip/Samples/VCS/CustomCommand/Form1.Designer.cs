﻿namespace CustomCommand
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
          this.menuStrip1 = new System.Windows.Forms.MenuStrip();
          this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.drawToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.lineToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
          this.polylineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.circleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.arcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.textToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.customCommanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.lineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.testToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.adLineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.toolStrip1 = new System.Windows.Forms.ToolStrip();
          this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
          this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
          this.loadFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.menuStrip1.SuspendLayout();
          this.toolStrip1.SuspendLayout();
          this.SuspendLayout();
          // 
          // menuStrip1
          // 
          this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.drawToolStripMenuItem,
            this.customCommanToolStripMenuItem,
            this.testToolStripMenuItem});
          this.menuStrip1.Location = new System.Drawing.Point(0, 0);
          this.menuStrip1.Name = "menuStrip1";
          this.menuStrip1.Size = new System.Drawing.Size(908, 24);
          this.menuStrip1.TabIndex = 0;
          this.menuStrip1.Text = "menuStrip1";
          // 
          // fileToolStripMenuItem
          // 
          this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem});
          this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
          this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
          this.fileToolStripMenuItem.Text = "File";
          // 
          // newToolStripMenuItem
          // 
          this.newToolStripMenuItem.Name = "newToolStripMenuItem";
          this.newToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
          this.newToolStripMenuItem.Text = "New";
          this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
          // 
          // openToolStripMenuItem
          // 
          this.openToolStripMenuItem.Name = "openToolStripMenuItem";
          this.openToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
          this.openToolStripMenuItem.Text = "Open...";
          this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
          // 
          // drawToolStripMenuItem
          // 
          this.drawToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lineToolStripMenuItem1,
            this.polylineToolStripMenuItem,
            this.circleToolStripMenuItem,
            this.arcToolStripMenuItem,
            this.textToolStripMenuItem});
          this.drawToolStripMenuItem.Name = "drawToolStripMenuItem";
          this.drawToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
          this.drawToolStripMenuItem.Text = "Draw";
          // 
          // lineToolStripMenuItem1
          // 
          this.lineToolStripMenuItem1.Name = "lineToolStripMenuItem1";
          this.lineToolStripMenuItem1.Size = new System.Drawing.Size(116, 22);
          this.lineToolStripMenuItem1.Text = "Line";
          this.lineToolStripMenuItem1.Click += new System.EventHandler(this.lineToolStripMenuItem1_Click);
          // 
          // polylineToolStripMenuItem
          // 
          this.polylineToolStripMenuItem.Name = "polylineToolStripMenuItem";
          this.polylineToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
          this.polylineToolStripMenuItem.Text = "Polyline";
          this.polylineToolStripMenuItem.Click += new System.EventHandler(this.polylineToolStripMenuItem_Click);
          // 
          // circleToolStripMenuItem
          // 
          this.circleToolStripMenuItem.Name = "circleToolStripMenuItem";
          this.circleToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
          this.circleToolStripMenuItem.Text = "Circle";
          this.circleToolStripMenuItem.Click += new System.EventHandler(this.circleToolStripMenuItem_Click);
          // 
          // arcToolStripMenuItem
          // 
          this.arcToolStripMenuItem.Name = "arcToolStripMenuItem";
          this.arcToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
          this.arcToolStripMenuItem.Text = "Arc";
          this.arcToolStripMenuItem.Click += new System.EventHandler(this.arcToolStripMenuItem_Click);
          // 
          // textToolStripMenuItem
          // 
          this.textToolStripMenuItem.Name = "textToolStripMenuItem";
          this.textToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
          this.textToolStripMenuItem.Text = "Text";
          this.textToolStripMenuItem.Click += new System.EventHandler(this.textToolStripMenuItem_Click);
          // 
          // customCommanToolStripMenuItem
          // 
          this.customCommanToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lineToolStripMenuItem});
          this.customCommanToolStripMenuItem.Name = "customCommanToolStripMenuItem";
          this.customCommanToolStripMenuItem.Size = new System.Drawing.Size(123, 20);
          this.customCommanToolStripMenuItem.Text = "CustomCommands";
          // 
          // lineToolStripMenuItem
          // 
          this.lineToolStripMenuItem.Name = "lineToolStripMenuItem";
          this.lineToolStripMenuItem.Size = new System.Drawing.Size(96, 22);
          this.lineToolStripMenuItem.Text = "Line";
          this.lineToolStripMenuItem.Click += new System.EventHandler(this.lineToolStripMenuItem_Click);
          // 
          // testToolStripMenuItem
          // 
          this.testToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adLineToolStripMenuItem,
            this.loadFileToolStripMenuItem});
          this.testToolStripMenuItem.Name = "testToolStripMenuItem";
          this.testToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
          this.testToolStripMenuItem.Text = "Test";
          // 
          // adLineToolStripMenuItem
          // 
          this.adLineToolStripMenuItem.Name = "adLineToolStripMenuItem";
          this.adLineToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
          this.adLineToolStripMenuItem.Text = "Draw Line";
          this.adLineToolStripMenuItem.Click += new System.EventHandler(this.adLineToolStripMenuItem_Click);
          // 
          // toolStrip1
          // 
          this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2});
          this.toolStrip1.Location = new System.Drawing.Point(0, 24);
          this.toolStrip1.Name = "toolStrip1";
          this.toolStrip1.Size = new System.Drawing.Size(908, 25);
          this.toolStrip1.TabIndex = 1;
          this.toolStrip1.Text = "toolStrip1";
          // 
          // toolStripButton1
          // 
          this.toolStripButton1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
          this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
          this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
          this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
          this.toolStripButton1.Name = "toolStripButton1";
          this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
          this.toolStripButton1.Text = "Draw Line";
          this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
          // 
          // toolStripButton2
          // 
          this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
          this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
          this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
          this.toolStripButton2.Name = "toolStripButton2";
          this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
          this.toolStripButton2.Text = "Draw Circle";
          this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
          // 
          // loadFileToolStripMenuItem
          // 
          this.loadFileToolStripMenuItem.Name = "loadFileToolStripMenuItem";
          this.loadFileToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
          this.loadFileToolStripMenuItem.Text = "Load file";
          this.loadFileToolStripMenuItem.Click += new System.EventHandler(this.loadFileToolStripMenuItem_Click);
          // 
          // Form1
          // 
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.ClientSize = new System.Drawing.Size(908, 551);
          this.Controls.Add(this.toolStrip1);
          this.Controls.Add(this.menuStrip1);
          this.MainMenuStrip = this.menuStrip1;
          this.Name = "Form1";
          this.Text = "Form1";
          this.Load += new System.EventHandler(this.Form1_Load);
          this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
          this.Resize += new System.EventHandler(this.Form1_Resize);
          this.menuStrip1.ResumeLayout(false);
          this.menuStrip1.PerformLayout();
          this.toolStrip1.ResumeLayout(false);
          this.toolStrip1.PerformLayout();
          this.ResumeLayout(false);
          this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customCommanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem drawToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lineToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem polylineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem circleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem textToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adLineToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripMenuItem loadFileToolStripMenuItem;
    }
}

